"""Validate module AND form with generated grammars-v4 VBA 7.1 parser.

Usage: python check_grammar.py /absolute/path/to/generated/parser
Requires antlr4-python3-runtime 4.13.2 and ANTLR 4.13.2 generated parser
from grammars-v4 commit 2766c2eed04f285dc763617c9459650892fcf5b9/vba/vba7_1.
"""
from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0, sys.argv[1])
from antlr4 import InputStream, CommonTokenStream
from antlr4.error.ErrorListener import ErrorListener
from vbaLexer import vbaLexer
from vbaParser import vbaParser

ROOT = Path(__file__).resolve().parents[1]

class Errors(ErrorListener):
    def __init__(self, filename, prefix_lines=0):
        self.filename = filename
        self.prefix_lines = prefix_lines
        self.errors = []
    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, error):
        self.errors.append(dict(file=self.filename, line=line-self.prefix_lines, column=column+1, message=msg))

errors = []
for filename, encoding in [('MergeDrawingsV16_22.bas', 'cp1251'), ('FORM_CODE.txt', 'utf-8')]:
    # FORM_CODE is pasteable code, not an exported module. Supply the export
    # attribute required by the grammar; report line numbers in the original.
    prefix = 'Attribute VB_Name = "frmDrawingOrder"\n' if filename == 'FORM_CODE.txt' else ''
    listener = Errors(filename, prefix.count('\n'))
    lexer = vbaLexer(InputStream(prefix + (ROOT / filename).read_text(encoding=encoding)))
    lexer.removeErrorListeners()
    lexer.addErrorListener(listener)
    parser = vbaParser(CommonTokenStream(lexer))
    parser.removeErrorListeners()
    parser.addErrorListener(listener)
    parser.startRule()
    errors.extend(listener.errors)
report = dict(parser='ANTLR 4.13.2 / grammars-v4 VBA 7.1',
              grammar_commit='2766c2eed04f285dc763617c9459650892fcf5b9', errors=errors,
              module_sha256=hashlib.sha256((ROOT / 'MergeDrawingsV16_22.bas').read_bytes()).hexdigest(),
              form_sha256=hashlib.sha256((ROOT / 'FORM_CODE.txt').read_bytes()).hexdigest(), native_vba_compile=False)
(ROOT / 'checks/grammar.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(bool(errors))
