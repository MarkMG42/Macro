"""Exercise the VBA fingerprint comparisons and model the two-pass mapping contract.

No COM/native SOLIDWORKS execution. Run with Python 3 from any directory.
"""
from pathlib import Path
import json
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'tools/merge_core.vba').read_text()


def load_fingerprint():
    body = SOURCE.split('Private Function SameViewFingerprint(', 1)[1].split('End Function', 1)[0]
    lines = ['def fingerprint(a, b, ignorePlacement=False):']
    for raw in body.splitlines()[2:]:
        line = raw.strip()
        if not line or line.startswith('SameViewFingerprint = False'):
            continue
        if line == 'If Not ignorePlacement Then':
            lines.append('    if not ignorePlacement:')
        elif line == 'End If':
            continue
        elif line == 'SameViewFingerprint = True':
            lines.append('    return True')
        else:
            assert line.startswith('If ') and line.endswith(' Then Exit Function'), line
            expr = line[3:-19]
            expr = re.sub(r'([ab])\("(\w+)"\)', r'\1["\2"]', expr)
            for cast in ('CLng', 'CStr', 'CDbl', 'CBool'):
                expr = re.sub(cast + r'\(([^()]*)\)', r'\1', expr)
            expr = expr.replace('<>', '!=').replace('Not ', 'not ')
            indent = '        ' if len(raw) - len(raw.lstrip()) == 8 else '    '
            lines.append(indent + 'if ' + expr + ': return False')
    env = dict(SameText=lambda a, b: a.lower() == b.lower(),
               StrComp=lambda a, b, mode: 0 if a == b else 1, vbBinaryCompare=0,
               NearValue=lambda a, b, tol: abs(a-b) <= tol, GEOM_TOL=1e-6, VALUE_TOL=1e-7)
    exec('\n'.join(lines), env)
    return env['fingerprint']


fingerprint = load_fingerprint()
BASE = dict(Type=4, Model='c:\\part.sldprt', Configuration='Default', Orientation='*Front',
            X=.1, Y=.2, Scale=1., Angle=0., Dimensions=3, Reversed=False, Partial=False, SurfaceOnly=False)


def matches(a, candidates):
    # Model MapCopiedSheet: strict first, fallback only for zero strict matches.
    for relaxed in (False, True):
        result = [b for b in candidates if fingerprint(a, b, relaxed)]
        if result:
            return result
    return []


class Regressions(unittest.TestCase):
    def test_plain_view_without_section(self):
        self.assertTrue(fingerprint(BASE, BASE))

    def test_paste_placement_then_restore(self):
        pasted = dict(BASE, X=.3, Y=.4, Scale=.5, Angle=.2)
        self.assertFalse(fingerprint(BASE, pasted))
        self.assertEqual(matches(BASE, [pasted]), [pasted])
        restored = dict(pasted, **{k: BASE[k] for k in ('X', 'Y', 'Scale', 'Angle')})
        self.assertTrue(fingerprint(BASE, restored))

    def test_intrinsic_mismatch_is_rejected(self):
        for field, value in dict(Type=2, Model='other', Configuration='other', Orientation='other',
                                 Dimensions=4, Reversed=True, Partial=True, SurfaceOnly=True).items():
            with self.subTest(field=field):
                self.assertFalse(fingerprint(BASE, dict(BASE, **{field: value}), True))

    def test_ambiguity_is_not_resolved_by_list_order(self):
        self.assertEqual(len(matches(BASE, [dict(BASE, X=.3), dict(BASE, X=.4)])), 2)
        self.assertEqual(matches(BASE, [dict(BASE, X=.3), BASE]), [BASE])
        self.assertEqual(len(matches(BASE, [BASE, BASE])), 2)

    def test_main_save_and_rebuild_scope(self):
        main = SOURCE.split('Public Sub main()', 1)[1].split('End Sub', 1)[0]
        prepare = SOURCE.split('Private Function PrepareMainDrawing(', 1)[1].split('End Function', 1)[0]
        self.assertIn('resultPath = mainPath', main)
        self.assertIn('targetPath = mainPath', main)
        self.assertNotIn('CloneInput', prepare)
        self.assertNotIn('RebuildDrawing', prepare)
        self.assertLess(prepare.index('fsoRun.CopyFile'), prepare.index('publishedDrawingPath = path'))
        self.assertNotIn('.Save3(', main.split('Failed:', 1)[1])
        self.assertIn('RebuildDrawing targetModel, sheetMap', SOURCE)
        self.assertIn('RebuildDrawing source, changedSheets', SOURCE)
        self.assertIn('Require count = 1', SOURCE)
        self.assertIn('Require SameViewFingerprint(a, b)', SOURCE)

    def test_form_preserves_full_paths(self):
        form = (ROOT / 'FORM_CODE.txt').read_text()
        self.assertIn('filesList.List(i - 1, 1) = fso.GetFileName(CStr(mFiles(i)))', form)
        self.assertIn('Set SelectedFiles = mFiles', form)
        self.assertIn('mFiles.Add path', form)


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Regressions))
    (ROOT / 'checks/regressions.json').write_text(json.dumps(dict(
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        kind='VBA fingerprint expression execution, mapping model and source assertions',
        native_solidworks_run=False), indent=2) + '\n')
    raise SystemExit(not result.wasSuccessful())
