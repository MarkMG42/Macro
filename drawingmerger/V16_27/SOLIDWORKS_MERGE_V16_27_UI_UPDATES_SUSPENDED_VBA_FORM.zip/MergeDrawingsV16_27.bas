Attribute VB_Name = "MergeDrawingsV16_27"
Option Explicit

Private Type OPENFILENAMEW
    lStructSize As Long
    hwndOwner As LongPtr
    hInstance As LongPtr
    lpstrFilter As LongPtr
    lpstrCustomFilter As LongPtr
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As LongPtr
    nMaxFile As Long
    lpstrFileTitle As LongPtr
    nMaxFileTitle As Long
    lpstrInitialDir As LongPtr
    lpstrTitle As LongPtr
    Flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As LongPtr
    lCustData As LongPtr
    lpfnHook As LongPtr
    lpTemplateName As LongPtr
    pvReserved As LongPtr
    dwReserved As Long
    FlagsEx As Long
End Type

Private Declare PtrSafe Function GetTickCount64 Lib "kernel32" () As LongLong

Private Declare PtrSafe Function GetOpenFileNameW _
    Lib "comdlg32.dll" (ByRef p As OPENFILENAMEW) As Long


Private Const OFN_HIDEREADONLY As Long = &H4
Private Const OFN_PATHMUSTEXIST As Long = &H800
Private Const OFN_FILEMUSTEXIST As Long = &H1000
Private Const OFN_ALLOWMULTISELECT As Long = &H200
Private Const OFN_EXPLORER As Long = &H80000

Private Const INSERT_MOVE_TO_END As Long = 2
Private Const RENAME_DUPLICATES As Long = 1

Private swApp As SldWorks.SldWorks
Private targetModel As SldWorks.ModelDoc2
Private targetDraw As SldWorks.DrawingDoc

' MERGE_DRAWINGS_V16_27_UI_UPDATES_SUSPENDED_20261114
' SOLIDWORKS 2025 x64 / VBA7. Entry point: main.
' Source files are read-only inputs. Only owned result/working drawings are edited.
' Native section/detail features are transferred with their complete parent chain.
' A successful PasteSheet is never accepted without verifying the view graph.

Private Const BUILD_ID As String = "MERGE_DRAWINGS_V16_27_UI_UPDATES_SUSPENDED_20261114"
Private Const GEOM_TOL As Double = 0.000001 ' metres; 0.001 mm
Private Const VALUE_TOL As Double = 0.0000001
' Matching identities remains strict; layout readback has practical tolerances.
Private Const POSITION_TOL As Double = 0.03 ' metres; +/-30 mm on each sheet axis
Private Const SCALE_TOL As Double = 0.001
Private Const ANGLE_TOL As Double = 0.00872664626 ' radians; 0.5 degrees
Private Const PAPER_TOL As Double = 0.0001 ' metres; 0.1 mm
Private Const MAX_ITEMS As Long = 100000
Private runFolder As String
Private publishedDrawingPath As String
Private runToken As String
Private logStream As Object
Private fsoRun As Object
Private expectedResult As Object
Private indexedModel As SldWorks.ModelDoc2
Private viewIndex As Object
Private perfRows As Collection
Private perfStarted As Double, perfStageStarted As Double
Private perfStage As String, perfActive As Boolean
Private Const FORCE_ALL_REBUILDS As Boolean = False
Private Const SUPPRESS_GRAPHICS As Boolean = True
Private Const SUPPRESS_FEATURE_TREE As Boolean = True
Private Const SUPPRESS_CONFIGURATION_TREE As Boolean = True
Private uiStates As Object
Private uiEnabled As Boolean
Private detailActive As Boolean, detailPrefix As String, detailStage As String
Private detailStarted As Double
Private runBusy As Boolean

Public Sub main()
    Dim mainPath As String, resultPath As String, pdfPath As String, resultPdfPath As String
    Dim sourceFiles As Collection, sourcePath As Variant
    Dim choice As VbMsgBoxResult, added As Long, fileIndex As Long
    Dim errors As Long, warnings As Long, saved As Boolean
    Dim actual As Object, failure As String, failureNumber As Long
    Dim verificationText As String
    Dim initialActive As SldWorks.ModelDoc2
    On Error GoTo Failed
    If runBusy Then Exit Sub
    runBusy = True
    detailActive = False
    RestoreAllUI
    perfActive = False
    perfStage = ""
    Set perfRows = Nothing
    InvalidateViewIndex
    Set swApp = Application.SldWorks
    Set initialActive = swApp.ActiveDoc
    Set targetModel = Nothing
    Set targetDraw = Nothing
    Set expectedResult = Nothing
    runFolder = ""
    publishedDrawingPath = ""
    Set fsoRun = CreateObject("Scripting.FileSystemObject")

    mainPath = PickOneDrawing("�������� �������� ������", "")
    If Len(mainPath) = 0 Then GoTo Finished
    CheckSavedInput mainPath
    InitRunFolder mainPath
    LogLine "BUILD_ID: " & BUILD_ID
    LogLine "SOLIDWORKS: " & swApp.RevisionNumber
    LogLine "MAIN: " & mainPath
    LogLine "OUTPUT folder: " & fsoRun.GetParentFolderName(mainPath)

    choice = MsgBox("��� ������� �������� �������?" & vbCrLf & vbCrLf & _
        "�� - ��� .slddrw �� ����� ��������� �������." & vbCrLf & _
        "��� - ������� �������." & vbCrLf & "������ - �����.", _
        vbYesNoCancel + vbQuestion, "����������� V16")
    If choice = vbCancel Then GoTo Finished
    If choice = vbYes Then
        Set sourceFiles = GetAllDrawingsInFolder(GetFolder(mainPath), mainPath)
    Else
        Set sourceFiles = PickMultipleDrawings("�������� �������� �������", GetFolder(mainPath))
    End If
    If sourceFiles Is Nothing Then GoTo Finished
    Set sourceFiles = GetOrderedSourceFiles(sourceFiles, mainPath)
    If sourceFiles Is Nothing Then GoTo Finished
    If sourceFiles.Count = 0 Then GoTo Finished
    PerfStart
    StartUIExperiment
    PerfNext "CHECK_INPUTS"
    For Each sourcePath In sourceFiles
        CheckSavedInput CStr(sourcePath)
    Next sourcePath

    PerfNext "PREPARE_MAIN"
    ' The selected main drawing is the result; no backup is created.
    resultPath = mainPath
    resultPdfPath = fsoRun.BuildPath(fsoRun.GetParentFolderName(mainPath), _
        fsoRun.GetBaseName(mainPath) & ".pdf")
    Set targetModel = PrepareMainDrawing(mainPath)
    SuspendDocumentUI targetModel
    LogLine "MODE save main; backup=disabled; audit=before_save_only"
    Set targetDraw = targetModel
    LogLine "MAIN sheets=" & expectedResult("Sheets").Count & _
        "; views=" & expectedResult("Views").Count

    For Each sourcePath In sourceFiles
        fileIndex = fileIndex + 1
        PerfNext "SOURCE_" & Format$(fileIndex, "0000")
        added = added + AppendDrawing(CStr(sourcePath), fileIndex)
    Next sourcePath

    PerfNext "UI_RESTORE"
    RestoreAllUI
    PerfNext "FINAL_AUDIT"
    RequireActive targetModel
    ' One complete audit of the finished drawing, immediately before Save3.
    Set actual = CaptureDrawing(targetModel)
    VerifyDrawing expectedResult, actual, "FINAL before save (complete)"
    WriteManifest actual, runFolder & "\verified_views.tsv"
    PerfNext "SAVE3"
    targetModel.ClearSelection2 True
    LogLine "SAVE result begin: " & targetModel.GetPathName
    saved = targetModel.Save3(swSaveAsOptions_Silent, errors, warnings)
    LogLine "SAVE result: " & saved & "; errors=" & errors & "; warnings=" & warnings
    Require saved And errors = 0, "�� ������� ��������� �������� ������: " & errors

    PerfNext "PDF_EXPORT"
    verificationText = "������ �������� ��������� ����� Save3. ����� ���������� ��������� ����� �� ����������."
    pdfPath = fsoRun.BuildPath(runFolder, "WORK_PDF.pdf")
    Require Not fsoRun.FileExists(pdfPath), "������� PDF ��� ����������."
    RequireActive targetModel
    targetModel.ClearSelection2 True
    saved = ExportDrawingToPDF(targetModel, pdfPath, errors, warnings)
    LogLine "PDF: " & saved & "; errors=" & errors & "; warnings=" & warnings
    Require saved And errors = 0, "������ ��������, �� ������� PDF �� ��������. ���: " & errors
    Require fsoRun.FileExists(pdfPath), "API ������� �� ��������, �� PDF �����������."
    Require fsoRun.GetFile(pdfPath).Size > 0, "������� ������ ���� PDF."
    PerfNext "PDF_PUBLISH"
    PublishPDF pdfPath, resultPdfPath
    LogLine "RESULT drawing: " & resultPath
    LogLine "RESULT PDF: " & resultPdfPath
    LogLine "SUCCESS sheets=" & targetDraw.GetSheetCount & "; added=" & added
    WriteStatus "SUCCESS", verificationText
    PerfFinish "SUCCESS"
    MsgBox "��������� �������", vbInformation, "����������� V16.27"
    GoTo Finished

Failed:
    failureNumber = Err.Number
    failure = Err.Description
    ' Capture the actual error before calling anything that can reset Err.
    On Error Resume Next
    If logStream Is Nothing Then InitFailureLog
    LogLine "FAILED " & failureNumber & ": " & failure
    LogLine "FAILED: no automatic Save3 of the unverified main drawing."
    WriteStatus "FAILED", failure & vbCrLf & "�������� ������: " & mainPath & vbCrLf & _
        "�������������� ��� ������ �� �����������; ���� Save3 ��� ���������, �������� ���� ��� ����������."
    RestoreAllUI
    PerfFinish "FAILED"
    Set targetDraw = Nothing
    If Not initialActive Is Nothing Then RequireActive initialActive
    MsgBox "������, ��������� ������", vbCritical, "����������� V16.27"
    On Error GoTo 0
Finished:
    On Error Resume Next
    RestoreAllUI
    PerfFinish "CANCELLED"
    If Not logStream Is Nothing Then logStream.Close
    Set logStream = Nothing
    InvalidateViewIndex
    runBusy = False
    On Error GoTo 0
End Sub

Private Function AppendDrawing(ByVal inputPath As String, ByVal fileIndex As Long) As Long
    Dim source As SldWorks.ModelDoc2
    Dim original As Object, staged As Object, current As Object
    Dim viewMap As Object, sheetMap As Object, rec As Object, copied As Object
    Dim propertyMap As Object, helperNames As Object, helperKey As Variant
    Dim changedSheets As Object
    Dim directSource As Boolean, sourceOpened As Boolean, sourceSheet As String
    Dim order As Collection, key As Variant, sheetKey As Variant, s As Object
    Dim newSheet As String, destSheet As String, name As String
    Dim view As SldWorks.View, dest As SldWorks.Sheet, item As Object
    Dim i As Long, n As Long, e As Long, message As String
    On Error GoTo Failed
    LogLine "SOURCE " & fileIndex & ": " & inputPath
    DetailStart fileIndex
    DetailNext "PREPARE_SOURCE"
    Set source = PrepareSource(inputPath, fileIndex, original, directSource, sourceOpened, sourceSheet)
    Set order = DependencyOrder(original("Views"))
    Set viewMap = NewDictionary()
    Set sheetMap = NewDictionary()
    Set propertyMap = NewDictionary()
    Set helperNames = NewDictionary()
    Set changedSheets = NewDictionary()

    DetailNext "CONSOLIDATE_SOURCE"
    ' Keep each root view on its original sheet. Bring its descendants to it.
    ' Ordinary families already on one sheet are left untouched.
    If directSource Then
        Set staged = original
    Else
        For Each key In order
            Set rec = original("Views")(CStr(key))
            Set view = FindView(source, CStr(key))
            Require Not view Is Nothing, "������� ��� ���������: " & CStr(key)
            If Not SameText(ViewSheetName(view), CStr(rec("Carrier"))) Then
                changedSheets(ViewSheetName(view)) = ViewSheetName(view)
                changedSheets(CStr(rec("Carrier"))) = CStr(rec("Carrier"))
                MoveView source, CStr(key), CStr(rec("Carrier")), CDbl(rec("Scale"))
            End If
        Next key
        RebuildDrawing source, changedSheets
        Set staged = CaptureDrawing(source)
    End If
    VerifyStructure original, staged, "SOURCE consolidated"
    ' Parent and child must now be on the SAME sheet before PasteSheet.
    For Each key In staged("Views").Keys
        Set rec = staged("Views")(CStr(key))
        If Len(CStr(rec("Parent"))) > 0 Then
            Set item = staged("Views")(CStr(rec("Parent")))
            Require SameText(CStr(rec("Sheet")), CStr(item("Sheet"))), _
                "�� ������� ������� ������������ �������: " & CStr(key)
        End If
    Next key

    DetailNext "COPY_AND_MAP_SHEETS"
    ' Transfer complete sheets in ORIGINAL order. The temporarily empty sheets
    ' carry their original format, sheet notes, tables, scale and paper settings.
    For Each sheetKey In original("Order")
        newSheet = CopyWholeSheet(source, CStr(sheetKey))
        sheetMap.Add CStr(sheetKey), newSheet
        Set current = CaptureDrawing(targetModel, newSheet)
        MapCopiedSheet staged, CStr(sheetKey), current, newSheet, viewMap
    Next sheetKey
    Require viewMap.Count = original("Views").Count, "�� ��� ���� ������������ ����� �������."

    DetailNext "MOVE_VIEWS"
    ' Move leaves first when spreading a family back across target sheets.
    ' This moves native features WITHIN a drawing, preserving their parent links.
    For i = order.Count To 1 Step -1
        key = CStr(order(i))
        Set rec = original("Views")(CStr(key))
        name = CStr(viewMap(CStr(key)))
        destSheet = CStr(sheetMap(CStr(rec("Sheet"))))
        Set view = FindView(targetModel, name)
        Require Not view Is Nothing, "�� ������ ����������� ���: " & name
        If Not SameText(ViewSheetName(view), destSheet) Then
            MoveView targetModel, name, destSheet, CDbl(rec("Scale"))
        End If
    Next i

    DetailNext "RESTORE_LAYOUT"
    ' Restore exact scale mode/position in parent-first order. No invented
    ' SetBaseView, no detached images, no recreated or flattened section geometry.
    For Each key In order
        Set rec = original("Views")(CStr(key))
        name = CStr(viewMap(CStr(key)))
        Set view = FindView(targetModel, name)
        Require Not view Is Nothing, "�� ������ ��� ��� ��������������: " & name
        RequireActive targetModel
        EnsureSheetActive targetModel, CStr(sheetMap(CStr(rec("Sheet")))), "RestoreView"
        RestoreView view, rec
    Next key
    DetailNext "SHEET_PROPERTIES"
    For Each sheetKey In original("Order")
        Set s = original("Sheets")(CStr(sheetKey))
        destSheet = CStr(sheetMap(CStr(sheetKey)))
        ' Apply sheet settings in the verified active-sheet context.
        EnsureSheetActive targetModel, destSheet, "Restore CustomPropertyView"
        targetModel.ClearSelection2 True
        Set dest = targetDraw.GetCurrentSheet
        name = MappedPropertyView(original, CStr(sheetKey), viewMap)
        LogLine "PROPERTY VIEW before: sheet=" & destSheet & "; source=[" & _
            CStr(s("PropertyView")) & "]; requested=[" & name & "]; current=[" & dest.CustomPropertyView & "]"
        name = LocalizeTargetPropertyView(original, CStr(sheetKey), destSheet, name, helperNames)
        propertyMap.Add CStr(sheetKey), name
        ApplySheetPropertySource dest, name, False
        LogLine "PROPERTY VIEW readback: sheet=" & destSheet & "; requested=[" & _
            name & "]; actual=[" & dest.CustomPropertyView & "]"
    Next sheetKey
    DetailNext "LINKED_NOTES"
    RestoreImportedLinkedNotes original, sheetMap, viewMap
    DetailNext "REBUILD_IMPORTED"
    RebuildDrawing targetModel, sheetMap
    DetailNext "POST_REBUILD_PLACEMENT"
    ' Rebuild can reapply projection alignment or inherited scale. Restore only
    ' actual drift, parent first, then restore notes moved along with those views.
    If RestoreImportedPlacementAfterRebuild(original, order, viewMap, sheetMap) Then
        RestoreImportedLinkedNotes original, sheetMap, viewMap
    End If

    ' Build the expected final drawing from the ORIGINAL snapshots, not from
    ' whatever happened to survive the paste. Only generated names are mapped.
    DetailNext "CAPTURE_IMPORTED"
    Set current = CaptureMappedSheets(targetModel, sheetMap)
    DetailNext "EXPECTED_RECORDS"
    For Each sheetKey In original("Order")
        Set rec = CloneRecord(original("Sheets")(CStr(sheetKey)))
        name = CStr(sheetMap(CStr(sheetKey)))
        rec("Name") = name
        rec("PropertyView") = CStr(propertyMap(CStr(sheetKey)))
        Set rec("LinkedNotes") = MappedLinkedNotes(rec("LinkedNotes"), viewMap)
        ' Imported sheets must not inherit the main drawing's property model.
        rec("SameCustomProp") = False
        expectedResult("Sheets").Add name, rec
        expectedResult("Order").Add name
    Next sheetKey
    For Each key In original("Views").Keys
        Set rec = CloneRecord(original("Views")(CStr(key)))
        name = CStr(viewMap(CStr(key)))
        rec("Name") = name
        Set rec("LinkedNotes") = MappedLinkedNotes(rec("LinkedNotes"), viewMap)
        rec("Sheet") = CStr(sheetMap(CStr(rec("Sheet"))))
        If Len(CStr(rec("Parent"))) > 0 Then rec("Parent") = CStr(viewMap(CStr(rec("Parent"))))
        ' PasteSheet(rename=yes) legitimately changes conflicting section labels.
        ' Keep the native new label, but never accept a changed parent identity.
        Set copied = current("Views")(name)
        rec("Label") = CStr(copied("Label"))
        expectedResult("Views").Add name, rec
    Next key
    For Each helperKey In helperNames.Keys
        Set copied = current("Views")(CStr(helperKey))
        Require SameText(CStr(copied("Model")), CStr(helperNames(helperKey)("PropertyModel"))), "���������� ������ ���������� ����."
        Require CStr(copied("Configuration")) = CStr(helperNames(helperKey)("PropertyConfiguration")), "���������� ������������ ���������� ����."
        Require CBool(copied("Visible")) = False, "��������� ��� ������ ���� �����."
        Require Len(CStr(copied("Parent"))) = 0, "� ���������� ���� �������� ��������."
        expectedResult("Views").Add CStr(helperKey), CloneRecord(copied)
    Next helperKey
    LogLine "SOURCE imported; full audit deferred until before Save3: " & fileIndex
    n = original("Sheets").Count
    DetailNext "RELEASE_SOURCE"
    ReleaseSource source, directSource, sourceOpened, sourceSheet
    DetailFinish "DONE"
    AppendDrawing = n
    Exit Function
Failed:
    e = Err.Number
    message = Err.Description
    On Error Resume Next
    DetailFinish "FAILED"
    ReleaseSource source, directSource, sourceOpened, sourceSheet
    On Error GoTo 0
    Err.Raise e, "AppendDrawing", inputPath & vbCrLf & message
End Function

Private Sub ApplySheetPropertySource(ByVal sheet As SldWorks.Sheet, _
    ByVal viewName As String, ByVal sameAsDocument As Boolean)
    Dim props As Variant, afterProps As Variant
    props = sheet.GetProperties2
    Require HasVectorElements(props, 8), "�� ��������� �������� ����� " & sheet.GetName
    Require UBound(props) >= 7, "�� �������� ����� ������� ����� " & sheet.GetName
    LogLine "PROPERTY MODE before: sheet=" & sheet.GetName & "; inherited=" & _
        CStr(FlagValue(CBool(props(7)))) & "; requested=" & CStr(FlagValue(sameAsDocument))
    ' The inheritance flag controls whether CustomPropertyView can take effect.
    ' Keep all other paper/template/scale settings unchanged.
    If FlagValue(CBool(props(7))) <> FlagValue(sameAsDocument) Then
        sheet.SetProperties2 CLng(props(0)), CLng(props(1)), CDbl(props(2)), CDbl(props(3)), _
            FlagValue(CBool(props(4))), CDbl(props(5)), CDbl(props(6)), FlagValue(sameAsDocument)
    End If
    afterProps = sheet.GetProperties2
    Require HasVectorElements(afterProps, 8), "�� �������� ��������� ��������� ������ ������� �����."
    Require UBound(afterProps) >= 7, "��� ����� ������ ������� ����� ���������."
    Require FlagValue(CBool(afterProps(7))) = FlagValue(sameAsDocument), _
        "�� ������������ ����� ��������� ������� ����� " & sheet.GetName
    If sameAsDocument = False Then
        If Not SameText(sheet.CustomPropertyView, viewName) Then sheet.CustomPropertyView = viewName
    End If
    LogLine "PROPERTY MODE readback: sheet=" & sheet.GetName & "; inherited=" & _
        CStr(FlagValue(CBool(afterProps(7)))) & "; view=[" & sheet.CustomPropertyView & "]"
End Sub

Private Function LocalPropertySourceView(ByVal snapshot As Object, ByVal sheetName As String) As String
    Dim sheet As Object, view As Object, key As Variant, name As String
    Set sheet = snapshot("Sheets")(sheetName)
    name = CStr(sheet("EffectivePropertyView"))
    Require Len(name) > 0, "��� ������������ ����-��������� ������� ����� " & sheetName
    Require snapshot("Views").Exists(name), "������� ���-�������� ������� " & name
    Set view = snapshot("Views")(name)
    ' Prefer the original source when it belongs to this sheet.
    If SameText(CStr(view("Sheet")), sheetName) Then
        LocalPropertySourceView = name
        Exit Function
    End If
    ' A different local view is equivalent only for the exact same model/configuration.
    For Each key In snapshot("Views").Keys
        Set view = snapshot("Views")(CStr(key))
        If SameText(CStr(view("Sheet")), sheetName) And _
            SameText(CStr(view("Model")), CStr(sheet("PropertyModel"))) And _
            CStr(view("Configuration")) = CStr(sheet("PropertyConfiguration")) Then
            LocalPropertySourceView = CStr(key)
            Exit Function
        End If
    Next key
    ' Some sheets have no local view of the property model. Keep the original source;
    ' the normal readback and post-rebuild checks must confirm cross-sheet support.
    LogLine "PROPERTY SOURCE cross-sheet required: sheet=" & sheetName & "; view=" & name
    LocalPropertySourceView = name
End Function

Private Function MappedPropertyView(ByVal snapshot As Object, ByVal sheetName As String, _
    ByVal viewMap As Object) As String
    Dim rec As Object, name As String, originalMode As String
    Set rec = snapshot("Sheets")(sheetName)
    name = CStr(rec("PropertyView"))
    originalMode = name
    ' Freeze the original effective source before joining documents with different defaults.
    If CBool(rec("SameCustomProp")) Then
        name = LocalPropertySourceView(snapshot, sheetName)
        Require viewMap.Exists(name), "�� ����������� �������� ������� ����� " & sheetName & ": " & name
        MappedPropertyView = CStr(viewMap(name))
        LogLine "PROPERTY SOURCE localize: sourceSheet=" & sheetName & "; sourceView=[" & name & _
            "]; mappedView=[" & MappedPropertyView & "]; inherited=False"
        Exit Function
    End If
    ' A real view name takes precedence over a localized special label.
    If Not viewMap.Exists(name) Then
        If SameText(name, "�� ���������") Or SameText(name, "Default") Then
            name = CStr(rec("FirstView"))
            Require Len(name) > 0, "��� ������� ���� ��� ��������� ������� ����� " & sheetName
            Require viewMap.Exists(name), "�� ����������� ������ ��� ������� ����� " & sheetName & ": " & name
            Require SameText(CStr(snapshot("Views")(name)("Sheet")), sheetName), _
                "������ ��� ������� ��������� � ������� �����: " & name
            LogLine "PROPERTY VIEW resolve default: sourceSheet=" & sheetName & _
                "; mode=[" & originalMode & "]; sourceView=[" & name & "]; mappedView=[" & CStr(viewMap(name)) & "]"
        End If
    End If
    If viewMap.Exists(name) Then name = CStr(viewMap(name))
    MappedPropertyView = name
End Function

Private Function EffectivePropertyView(ByVal snapshot As Object, ByVal sheetName As String) As String
    Dim rec As Object, sourceSheet As String, name As String, sheetNo As Long
    Set rec = snapshot("Sheets")(sheetName)
    sourceSheet = sheetName
    If CBool(rec("SameCustomProp")) And CBool(snapshot("MatchPropertySheets")) Then
        sheetNo = CLng(snapshot("PropertySheetNo"))
        Require sheetNo >= 1 And sheetNo <= snapshot("Order").Count, _
            "������������ ����� ����� ������� ���������: " & sheetNo
        sourceSheet = CStr(snapshot("Order")(sheetNo))
        Set rec = snapshot("Sheets")(sourceSheet)
    End If
    name = CStr(rec("PropertyView"))
    If snapshot("Views").Exists(name) = False Then
        Select Case LCase$(Trim$(name))
            Case "", "default", "�� ���������", _
                "��������� � ������, ��������� � ��������� ���������", _
                "same as sheet specified in document properties"
                name = CStr(rec("FirstView"))
            Case Else
                Require False, "�� ��������� �������� ������� ����� " & sourceSheet & ": [" & name & "]"
        End Select
    End If
    If Len(name) > 0 Then
        Require snapshot("Views").Exists(name), "������� ����������� ��� �������: " & name
    End If
    EffectivePropertyView = name
End Function

Private Function CaptureDrawing(ByVal model As SldWorks.ModelDoc2, _
    Optional ByVal onlySheet As String = "", Optional ByVal selectedSheets As Object = Nothing) As Object
    Dim result As Object, sheets As Object, views As Object, rec As Object, sheetRec As Object
    Dim order As Collection, names As Variant, props As Variant, p As Variant, bounds As Variant
    Dim drawing As SldWorks.DrawingDoc, sheet As SldWorks.Sheet
    Dim view As SldWorks.View, parent As SldWorks.View, refDoc As SldWorks.ModelDoc2
    Dim section As SldWorks.DrSection
    Dim key As Variant, i As Long, guard As Long, activeSheet As String
    RequireActive model
    Set drawing = model
    Set sheet = drawing.GetCurrentSheet
    Require Not sheet Is Nothing, "�� ������� ������� ���� ��� ������ �������."
    activeSheet = sheet.GetName
    names = drawing.GetSheetNames
    Require HasVectorElements(names, 1), "�� ������� ������ ������: " & model.GetTitle
    Set result = NewDictionary()
    result.Add "MatchPropertySheets", FlagValue(model.Extension.GetUserPreferenceToggle( _
        swDrawingSheetsMatchCustomPropVals, swDetailingNoOptionSpecified))
    result.Add "PropertySheetNo", model.Extension.GetUserPreferenceInteger( _
        swDrawingSheetCustomPropSheetNo, swDetailingNoOptionSpecified)
    LogLine "PROPERTY DOCUMENT: doc=" & model.GetPathName & "; match=" & _
        CStr(result("MatchPropertySheets")) & "; sheetNo=" & CStr(result("PropertySheetNo"))
    Set sheets = NewDictionary()
    Set views = NewDictionary()
    Set order = New Collection
    For i = LBound(names) To UBound(names)
        If Not selectedSheets Is Nothing Then
            If Not selectedSheets.Exists(CStr(names(i))) Then GoTo NextCaptureSheet
        End If
        If Len(onlySheet) > 0 Then
            If Not SameText(CStr(names(i)), onlySheet) Then GoTo NextCaptureSheet
        End If
        EnsureSheetActive model, CStr(names(i)), "CaptureDrawing"
        Set sheet = drawing.GetCurrentSheet
        Require SameText(sheet.GetName, CStr(names(i))), "����������� �������� ����."
        props = sheet.GetProperties2
        Require HasVectorElements(props, 8), "�� ��������� ��������� ����� " & sheet.GetName
        Require UBound(props) >= 7, "�� ������� ���� ��������� ������� ����� " & sheet.GetName
        Set sheetRec = NewDictionary()
        sheetRec.Add "Name", sheet.GetName
        sheetRec.Add "Width", CDbl(props(5))
        sheetRec.Add "Height", CDbl(props(6))
        sheetRec.Add "Scale1", CDbl(props(2))
        sheetRec.Add "Scale2", CDbl(props(3))
        sheetRec.Add "FirstAngle", FlagValue(CBool(props(4)))
        sheetRec.Add "PropertyView", sheet.CustomPropertyView
        sheetRec.Add "SameCustomProp", FlagValue(CBool(props(7)))
        sheetRec.Add "FormatVisible", FlagValue(sheet.SheetFormatVisible)
        Set view = drawing.GetFirstView
        Require Not view Is Nothing, "�� ������� ��������� ��� ����� " & sheet.GetName
        Require view.Type = swDrawingSheet, "GetFirstView �� �������� ��������� ����� �����."
        AddAnnotationStats sheetRec, view
        sheets.Add sheet.GetName, sheetRec
        order.Add sheet.GetName
        Set view = view.GetNextView ' Exclude the sheet pseudo-view exactly once.
        sheetRec.Add "FirstView", ""
        If Not view Is Nothing Then sheetRec("FirstView") = view.GetName2
        Do While Not view Is Nothing
            guard = guard + 1
            Require guard <= MAX_ITEMS, "������������ ������ �����."
            Set rec = NewDictionary()
            rec.Add "Name", view.GetName2
            rec.Add "Sheet", sheet.GetName
            rec.Add "Type", CLng(view.Type)
            rec.Add "Model", NormalizePath(view.GetReferencedModelName)
            rec.Add "Configuration", view.ReferencedConfiguration
            If Len(CStr(rec("Model"))) > 0 Then
                Set refDoc = view.ReferencedDocument
                Require Not refDoc Is Nothing, "�� ��������� ������ ���� " & view.GetName2
                SuspendDocumentUI refDoc
                rec("Model") = NormalizePath(refDoc.GetPathName)
            End If
            Set parent = view.GetBaseView
            rec.Add "Parent", ""
            If Not parent Is Nothing Then rec("Parent") = parent.GetName2
            If view.Type = swDrawingSectionView Or view.Type = swDrawingDetailView Then
                Require Not parent Is Nothing, "� �������/��������� ���� ����������� ��������: " & view.GetName2
            End If
            p = view.Position
            bounds = view.GetOutline
            Require HasVectorElements(p, 2) And HasVectorElements(bounds, 4), "�� �������� ��������� ���� " & view.GetName2
            rec.Add "X", CDbl(p(0))
            rec.Add "Y", CDbl(p(1))
            rec.Add "BoxWidth", CDbl(bounds(2)) - CDbl(bounds(0))
            rec.Add "BoxHeight", CDbl(bounds(3)) - CDbl(bounds(1))
            rec.Add "Scale", CDbl(view.ScaleDecimal)
            rec.Add "SheetScale", CLng(view.UseSheetScale)
            rec.Add "ParentScale", FlagValue(view.UseParentScale)
            rec.Add "Angle", CDbl(view.Angle)
            rec.Add "Orientation", view.GetOrientationName
            rec.Add "Locked", FlagValue(view.PositionLocked)
            rec.Add "Alignment", CLng(view.GetAlignment)
            rec.Add "Suppressed", CLng(view.SuppressState)
            rec.Add "Visible", FlagValue(view.GetVisible)
            rec.Add "Label", ""
            rec.Add "Reversed", False
            rec.Add "Partial", False
            rec.Add "SurfaceOnly", False
            rec.Add "Hatches", CLng(view.GetFaceHatchCount)
            If view.Type = swDrawingSectionView Then
                Set section = view.GetSection
                Require Not section Is Nothing, "�� �������� ������ ������� " & view.GetName2
                rec("Label") = section.GetLabel
                rec("Reversed") = FlagValue(section.GetReversedCutDirection)
                rec("Partial") = FlagValue(section.GetPartialSection)
                rec("SurfaceOnly") = FlagValue(section.GetDisplayOnlySurfaceCut)
            End If
            AddAnnotationStats rec, view
            Require Not views.Exists(CStr(rec("Name"))), "������������� ��� ����: " & CStr(rec("Name"))
            views.Add CStr(rec("Name")), rec
            Set view = view.GetNextView
        Loop
NextCaptureSheet:
    Next i
    For Each key In views.Keys
        Set rec = views(CStr(key))
        If Len(CStr(rec("Parent"))) > 0 Then
            If selectedSheets Is Nothing Then
                If Len(onlySheet) = 0 Then Require views.Exists(CStr(rec("Parent"))), "�������� ����������� � ���������: " & CStr(key)
            End If
        End If
    Next key
    result.Add "Sheets", sheets
    result.Add "Views", views
    result.Add "Order", order
    For Each key In sheets.Keys
        Set sheetRec = sheets(CStr(key))
        sheetRec.Add "EffectivePropertyView", ""
        If selectedSheets Is Nothing Then
            If Len(onlySheet) = 0 Then sheetRec("EffectivePropertyView") = EffectivePropertyView(result, CStr(key))
        End If
        sheetRec.Add "PropertyModel", ""
        sheetRec.Add "PropertyConfiguration", ""
        If Len(CStr(sheetRec("EffectivePropertyView"))) > 0 Then
            Set rec = views(CStr(sheetRec("EffectivePropertyView")))
            sheetRec("PropertyModel") = CStr(rec("Model"))
            sheetRec("PropertyConfiguration") = CStr(rec("Configuration"))
        End If
    Next key
    EnsureSheetActive model, activeSheet, "CaptureDrawing restore"
    Set CaptureDrawing = result
End Function

Private Sub AddAnnotationStats(ByVal rec As Object, ByVal view As SldWorks.View)
    Dim annotation As SldWorks.Annotation, dangling As Long, guard As Long
    rec.Add "Dimensions", CLng(view.GetDimensionCount4)
    rec.Add "ApprovedOmissions", ApprovedDimensionCount(view)
    rec.Add "NoteCount", CLng(view.GetNoteCount)
    rec.Add "Annotations", CLng(view.GetAnnotationCount)
    Set annotation = view.GetFirstAnnotation3
    Do While Not annotation Is Nothing
        guard = guard + 1
        Require guard <= MAX_ITEMS, "������������ ������ ���������."
        If annotation.IsDangling Then dangling = dangling + 1
        Set annotation = annotation.GetNext3
    Loop
    rec.Add "Dangling", dangling
    rec.Add "LinkedNotes", CaptureLinkedNotes(view)
End Sub

Private Function ApprovedDimensionCount(ByVal view As SldWorks.View) As Long
    Dim dd As SldWorks.DisplayDimension, modelDimension As SldWorks.Dimension
    Dim modelName As String, orientation As String, count As Long
    If view.Type = swDrawingSheet Then Exit Function
    modelName = fsoRun.GetFileName(view.GetReferencedModelName)
    If Not SameText(modelName, "����-65-65-1-2-�� �� ��.sldasm") Then Exit Function
    orientation = view.GetOrientationName
    If Not SameText(orientation, "*�������") And Not SameText(orientation, "*Front") Then Exit Function
    Set dd = view.GetFirstDisplayDimension5
    Do While Not dd Is Nothing
        count = count + 1
        Require count <= MAX_ITEMS, "������������ �������� ������������ �������."
        Set modelDimension = dd.GetDimension2(0)
        If Not modelDimension Is Nothing Then
            If SameText(Left$(modelDimension.FullName, 5), "RD18@") Then
                If NearValue(modelDimension.SystemValue, 0.532, 0.000001) Then
                    ApprovedDimensionCount = ApprovedDimensionCount + 1
                    LogLine "APPROVED OMISSION: RD18 532 mm; view=" & view.GetName2
                End If
            End If
        End If
        Set dd = dd.GetNext5
    Loop
    Require ApprovedDimensionCount <= 1, "������������� ���������� RD18."
End Function

Private Function ApprovedOmissions(ByVal rec As Object) As Long
    If rec.Exists("ApprovedOmissions") Then ApprovedOmissions = CLng(rec("ApprovedOmissions"))
End Function

Private Function RequiredDimensionCount(ByVal rec As Object) As Long
    RequiredDimensionCount = CLng(rec("Dimensions")) - ApprovedOmissions(rec)
End Function

Private Function DependencyOrder(ByVal views As Object) As Collection
    Dim result As Collection, key As Variant, node As Object, parent As String
    Dim rec As Object, depth As Long, maxDepth As Long, level As Long
    Set result = New Collection
    For Each key In views.Keys
        Set rec = views(CStr(key))
        Set node = rec
        depth = 0
        parent = CStr(node("Parent"))
        Do While Len(parent) > 0
            depth = depth + 1
            Require depth <= views.Count, "���� � ������������ ������: " & CStr(key)
            Require views.Exists(parent), "�� ������ �������� " & parent
            Set node = views(parent)
            parent = CStr(node("Parent"))
        Loop
        rec("Depth") = depth
        rec("Carrier") = CStr(node("Sheet"))
        If depth > maxDepth Then maxDepth = depth
    Next key
    For level = 0 To maxDepth
        For Each key In views.Keys
            Set rec = views(CStr(key))
            If CLng(rec("Depth")) = level Then result.Add CStr(key)
        Next key
    Next level
    Set DependencyOrder = result
End Function

Private Sub MoveView(ByVal model As SldWorks.ModelDoc2, ByVal viewName As String, _
    ByVal sheetName As String, ByVal desiredScale As Double)
    Dim drawing As SldWorks.DrawingDoc, view As SldWorks.View
    Dim fromSheet As String, before As Object, after As Object, touched As Object
    Dim p As Variant, locked As Boolean
    RequireOwnedPath model.GetPathName
    RequireActive model
    Set drawing = model
    Set view = FindView(model, viewName)
    Require Not view Is Nothing, "�� ������ ����������� ��� " & viewName
    fromSheet = ViewSheetName(view)
    If SameText(fromSheet, sheetName) Then Exit Sub
    Set touched = NewDictionary()
    touched(fromSheet) = True
    touched(sheetName) = True
    Set before = CaptureStructure(model, touched)
    EnsureSheetActive model, fromSheet, "MoveView source"
    Set view = FindView(model, viewName)
    locked = FlagValue(view.PositionLocked)
    p = view.Position
    view.PositionLocked = False
    ' A child temporarily on a sheet with another scale must not change size.
    view.UseParentScale = False
    view.UseSheetScale = 0
    view.ScaleDecimal = desiredScale
    SelectViewForMove model, view
    InvalidateViewIndex
    model.EditCut
    EnsureSheetActive model, sheetName, "MoveView destination"
    drawing.EditSheet
    model.ClearSelection2 True
    ' Paste a drawing view into the verified active sheet, with no selection.
    LogLine "PASTE VIEW begin: view=" & viewName & "; destination=" & drawing.GetCurrentSheet.GetName
    InvalidateViewIndex
    model.Paste
    LogLine "PASTE VIEW returned: view=" & viewName
    Set view = FindView(model, viewName)
    Require Not view Is Nothing, "���������� ��� �� ��������: " & viewName
    Require SameText(ViewSheetName(view), sheetName), "��� �������� �� �� ��� ����: " & viewName
    ' Native paste may use the current cursor location. Retain coordinates so
    ' different sections are not inadvertently stacked at the paste location.
    view.PositionLocked = False
    view.Position = p
    view.PositionLocked = locked
    Set after = CaptureStructure(model, touched)
    VerifyStructure before, after, "MOVE " & viewName
    LogLine "MOVE [" & viewName & "] " & fromSheet & " -> " & sheetName
End Sub

Private Sub SelectViewForMove(ByVal model As SldWorks.ModelDoc2, ByVal view As SldWorks.View)
    Dim objects(0) As Object, count As Long, byName As Boolean
    Dim viewName As String, sheetName As String
    viewName = view.GetName2
    sheetName = ViewSheetName(view)
    EnsureSheetActive model, sheetName, "SelectViewForMove"
    model.ClearSelection2 True
    Set objects(0) = view
    count = model.Extension.MultiSelect2(objects, False, Nothing)
    LogLine "SELECT VIEW object: name=" & viewName & "; sheet=" & sheetName & "; count=" & count
    If SelectedViewMatches(model, viewName, sheetName) Then Exit Sub
    ' Compatibility fallback; never cut solely on a Boolean selection result.
    model.ClearSelection2 True
    byName = model.Extension.SelectByID2(viewName, "DRAWINGVIEW", 0, 0, 0, False, 0, Nothing, 0)
    LogLine "SELECT VIEW name: name=" & viewName & "; api=" & CStr(byName)
    If SelectedViewMatches(model, viewName, sheetName) Then Exit Sub
    model.ClearSelection2 True
    Require False, "�� ������ ����������� ��� " & viewName & "; ����=" & sheetName & _
        "; MultiSelect2=" & count & "; SelectByID2=" & CStr(byName)
End Sub

Private Function SelectedViewMatches(ByVal model As SldWorks.ModelDoc2, _
    ByVal viewName As String, ByVal sheetName As String) As Boolean
    Dim manager As SldWorks.SelectionMgr, selectedObject As Object
    Dim selectedView As SldWorks.View, count As Long, objectType As Long
    Set manager = model.SelectionManager
    count = manager.GetSelectedObjectCount2(-1)
    LogLine "SELECT CHECK count=" & count
    If count <> 1 Then Exit Function
    objectType = manager.GetSelectedObjectType3(1, -1)
    LogLine "SELECT CHECK type=" & objectType
    Set selectedObject = manager.GetSelectedObject6(1, -1)
    If selectedObject Is Nothing Then Exit Function
    If Not TypeOf selectedObject Is SldWorks.View Then Exit Function
    Set selectedView = selectedObject
    LogLine "SELECT CHECK view=" & selectedView.GetName2 & "; sheet=" & ViewSheetName(selectedView)
    SelectedViewMatches = SameText(selectedView.GetName2, viewName) And _
        SameText(ViewSheetName(selectedView), sheetName)
End Function

Private Sub RestoreView(ByVal view As SldWorks.View, ByVal rec As Object)
    Dim p(1) As Double, actual As Variant, attempt As Long
    If ViewPlacementMatches(view, rec) Then Exit Sub
    view.PositionLocked = False
    ' Reapply scale only when necessary: avoid perturbing ordinary pasted views.
    If FlagValue(view.UseParentScale) <> CBool(rec("ParentScale")) Or _
       view.UseSheetScale <> CLng(rec("SheetScale")) Or _
       Not NearValue(view.ScaleDecimal, CDbl(rec("Scale")), SCALE_TOL) Then
        view.UseParentScale = False
        view.UseSheetScale = 0
        view.ScaleDecimal = CDbl(rec("Scale"))
        If CBool(rec("ParentScale")) Then
            view.UseParentScale = True
        ElseIf CLng(rec("SheetScale")) <> 0 Then
            view.UseSheetScale = 1
        End If
    End If
    If Not NearValue(view.Angle, CDbl(rec("Angle")), ANGLE_TOL) Then view.Angle = CDbl(rec("Angle"))
    p(0) = CDbl(rec("X"))
    p(1) = CDbl(rec("Y"))
    ' Position can be reported with a shifted origin after note layout changes.
    ' Correct by the measured residual; never remove native view alignment.
    For attempt = 1 To 3
        actual = view.Position
        Require HasVectorElements(actual, 2), "��� ��������� ������������������ ����."
        If NearValue(CDbl(actual(0)), CDbl(rec("X")), POSITION_TOL) And _
            NearValue(CDbl(actual(1)), CDbl(rec("Y")), POSITION_TOL) Then Exit For
        view.Position = p
        actual = view.Position
        Require HasVectorElements(actual, 2), "��� ��������� ����� ��������� ������� ����."
        LogLine "POSITION readback: view=" & view.GetName2 & "; attempt=" & attempt & _
            "; requestedX=" & p(0) & "; requestedY=" & p(1) & "; actualX=" & actual(0) & "; actualY=" & actual(1)
        p(0) = p(0) + CDbl(rec("X")) - CDbl(actual(0))
        p(1) = p(1) + CDbl(rec("Y")) - CDbl(actual(1))
    Next attempt
    view.PositionLocked = CBool(rec("Locked"))
    ' Native alignment is retained. Layout differences within POSITION_TOL are
    ' accepted; lock/alignment mode differences are warnings in the final audit.
End Sub

Private Function ViewPlacementMatches(ByVal view As SldWorks.View, ByVal rec As Object) As Boolean
    Dim p As Variant
    p = view.Position
    Require HasVectorElements(p, 2), "��� ��������� ���� ����� ������������."
    If Not NearValue(CDbl(p(0)), CDbl(rec("X")), POSITION_TOL) Then Exit Function
    If Not NearValue(CDbl(p(1)), CDbl(rec("Y")), POSITION_TOL) Then Exit Function
    If Not NearValue(view.ScaleDecimal, CDbl(rec("Scale")), SCALE_TOL) Then Exit Function
    If Not NearValue(view.Angle, CDbl(rec("Angle")), ANGLE_TOL) Then Exit Function
    ViewPlacementMatches = True
End Function

Private Function RestoreImportedPlacementAfterRebuild(ByVal original As Object, ByVal order As Collection, _
    ByVal viewMap As Object, ByVal sheetMap As Object) As Boolean
    Dim key As Variant, rec As Object, view As SldWorks.View, p As Variant
    For Each key In order
        Set rec = original("Views")(CStr(key))
        Set view = FindView(targetModel, CStr(viewMap(CStr(key))))
        Require Not view Is Nothing, "������� ����������� ��� ����� ������������."
        EnsureSheetActive targetModel, CStr(sheetMap(CStr(rec("Sheet")))), "Post-rebuild placement"
        If Not ViewPlacementMatches(view, rec) Then
            p = view.Position
            LogLine "POST REBUILD placement: view=" & view.GetName2 & "; x=" & CStr(p(0)) & _
                "; expectedX=" & CStr(rec("X")) & "; y=" & CStr(p(1)) & "; expectedY=" & CStr(rec("Y")) & _
                "; scale=" & CStr(view.ScaleDecimal) & "; expectedScale=" & CStr(rec("Scale")) & _
                "; angle=" & CStr(view.Angle) & "; expectedAngle=" & CStr(rec("Angle"))
            RestoreView view, rec
            Require ViewPlacementMatches(view, rec), "�� ������������� ���������� ����� ������������: " & view.GetName2
            RestoreImportedPlacementAfterRebuild = True
        End If
    Next key
End Function

Private Sub SelectSheetForCopy(ByVal model As SldWorks.ModelDoc2, ByVal sheet As SldWorks.Sheet)
    Dim objects(0) As Object, count As Long, ok As Boolean
    Dim sheetName As String, props As Variant, x As Double, y As Double
    sheetName = sheet.GetName
    EnsureSheetActive model, sheetName, "SelectSheetForCopy"
    model.ClearSelection2 True
    Set objects(0) = sheet
    count = model.Extension.MultiSelect2(objects, False, Nothing)
    LogLine "SELECT SHEET object: sheet=" & sheetName & "; count=" & count
    If SelectedSheetMatches(model, sheetName) Then Exit Sub
    ' Preserve the previous selection routes, but verify their actual result.
    props = sheet.GetProperties2
    x = CDbl(props(5)) / 2#
    y = CDbl(props(6)) / 2#
    model.ClearSelection2 True
    ok = model.Extension.SelectByID2(sheetName, "SHEET", x, y, 0, False, 0, Nothing, 0)
    LogLine "SELECT SHEET name: api=" & CStr(ok)
    If SelectedSheetMatches(model, sheetName) Then Exit Sub
    model.ClearSelection2 True
    ok = model.Extension.SelectByID2("", "SHEET", x, y, 0, False, 0, Nothing, 0)
    LogLine "SELECT SHEET centre: api=" & CStr(ok)
    If SelectedSheetMatches(model, sheetName) Then Exit Sub
    model.ClearSelection2 True
    ok = model.Extension.SelectByID2("", "SHEET", 0, 0, 0, False, 0, Nothing, 0)
    LogLine "SELECT SHEET origin: api=" & CStr(ok)
    If SelectedSheetMatches(model, sheetName) Then Exit Sub
    model.ClearSelection2 True
    Require False, "�� ������ ���� ��� ����������� " & sheetName
End Sub

Private Function SelectedSheetMatches(ByVal model As SldWorks.ModelDoc2, ByVal sheetName As String) As Boolean
    Dim manager As SldWorks.SelectionMgr, selectedObject As Object
    Dim selectedSheet As SldWorks.Sheet, count As Long
    Set manager = model.SelectionManager
    count = manager.GetSelectedObjectCount2(-1)
    LogLine "SELECT SHEET CHECK count=" & count
    If count <> 1 Then Exit Function
    LogLine "SELECT SHEET CHECK type=" & manager.GetSelectedObjectType3(1, -1)
    Set selectedObject = manager.GetSelectedObject6(1, -1)
    If selectedObject Is Nothing Then Exit Function
    If Not TypeOf selectedObject Is SldWorks.Sheet Then Exit Function
    Set selectedSheet = selectedObject
    LogLine "SELECT SHEET CHECK name=" & selectedSheet.GetName
    SelectedSheetMatches = SameText(selectedSheet.GetName, sheetName)
End Function

Private Function CopyWholeSheet(ByVal source As SldWorks.ModelDoc2, ByVal sheetName As String) As String
    Dim drawing As SldWorks.DrawingDoc, sheet As SldWorks.Sheet
    Dim oldNames As Object, names As Variant, key As Variant
    Dim countBefore As Long, countAfter As Long, attempt As Long, found As Long
    Dim ok As Boolean
    Set drawing = source
    RequireActive source
    EnsureSheetActive source, sheetName, "CopyWholeSheet"
    drawing.EditSheet
    Set sheet = drawing.GetCurrentSheet
    Set oldNames = NewDictionary()
    names = targetDraw.GetSheetNames
    For Each key In names
        oldNames.Add CStr(key), True
    Next key
    countBefore = targetDraw.GetSheetCount
    SelectSheetForCopy source, sheet
    source.EditCopy
    ' Nothing that changes the source selection occurs between select and copy.
    RequireActive targetModel
    Set targetDraw = targetModel
    targetModel.ClearSelection2 True
    For attempt = 1 To 3
        InvalidateViewIndex
        ok = targetDraw.PasteSheet(INSERT_MOVE_TO_END, RENAME_DUPLICATES)
        countAfter = targetDraw.GetSheetCount
        If ok Then Exit For
        ' Retrying after a partial mutation could duplicate sheets. Never do that.
        Require countAfter = countBefore, "PasteSheet ������ False, �� ������� ����� ������."
    Next attempt
    Require ok And countAfter = countBefore + 1, "PasteSheet �� ������� ����� ���� ����: " & sheetName
    names = targetDraw.GetSheetNames
    For Each key In names
        If Not oldNames.Exists(CStr(key)) Then
            CopyWholeSheet = CStr(key)
            found = found + 1
        End If
    Next key
    Require found = 1, "������ ���������� ���������� ����������� ����."
    Require SameText(CStr(names(UBound(names))), CopyWholeSheet), "����� ���� �� �������� � �����."
    LogLine "SHEET [" & sheetName & "] -> [" & CopyWholeSheet & "]"
End Function

Private Sub MapCopiedSheet(ByVal source As Object, ByVal sourceSheet As String, _
    ByVal target As Object, ByVal targetSheet As String, ByVal mapping As Object)
    Dim order As Collection, used As Object, rec As Object, candidate As Object
    Dim key As Variant, candidateKey As Variant, mappedParent As String
    Dim match As String, count As Long, expectedCount As Long, actualCount As Long
    Dim relaxed As Long
    Set order = DependencyOrder(source("Views"))
    Set used = NewDictionary()
    For Each candidateKey In target("Views").Keys
        Set candidate = target("Views")(CStr(candidateKey))
        If SameText(CStr(candidate("Sheet")), targetSheet) Then actualCount = actualCount + 1
    Next candidateKey
    For Each key In order
        Set rec = source("Views")(CStr(key))
        If SameText(CStr(rec("Sheet")), sourceSheet) Then
            expectedCount = expectedCount + 1
            mappedParent = ""
            If Len(CStr(rec("Parent"))) > 0 Then
                Require mapping.Exists(CStr(rec("Parent"))), "�������� �� ����������� �� ��������� ����."
                mappedParent = CStr(mapping(CStr(rec("Parent"))))
            End If
            ' Prefer an exact match. PasteSheet can change placement/scale before
            ' RestoreView runs; accept only a UNIQUE intrinsic match in that case.
            For relaxed = 0 To 2
                count = 0
                match = ""
                For Each candidateKey In target("Views").Keys
                    Set candidate = target("Views")(CStr(candidateKey))
                    If SameText(CStr(candidate("Sheet")), targetSheet) And Not used.Exists(CStr(candidateKey)) Then
                        If SameText(CStr(candidate("Parent")), mappedParent) Then
                            If SameCopiedViewFingerprint(rec, candidate, relaxed) Then
                                count = count + 1
                                match = CStr(candidateKey)
                            End If
                        End If
                    End If
                Next candidateKey
                If count <> 0 Then Exit For
            Next relaxed
            If relaxed > 0 And count = 1 Then LogLine "MAP deferred layout/count audit: " & CStr(key) & "; pass=" & relaxed
            If count <> 1 Then
                LogViewFingerprint "MAP expected", rec
                For Each candidateKey In target("Views").Keys
                    Set candidate = target("Views")(CStr(candidateKey))
                    LogViewFingerprint "MAP candidate", candidate
                Next candidateKey
            End If
            Require count = 1, "������������� ��� ���������� ��� [" & CStr(key) & _
                "]; ����������=" & count & "; ����=" & targetSheet
            mapping.Add CStr(key), match
            used.Add match, True
            LogLine "MAP [" & CStr(key) & "] -> [" & match & "]; parent=[" & mappedParent & "]"
        End If
    Next key
    Require actualCount = expectedCount, "���������� ����� ����� �� ����� " & targetSheet & _
        ": ���������=" & expectedCount & "; ��������=" & actualCount
End Sub

Private Function SameCopiedViewFingerprint(ByVal original As Object, ByVal candidate As Object, ByVal pass As Long) As Boolean
    Dim identity As Object
    If pass < 2 Then
        SameCopiedViewFingerprint = SameViewFingerprint(original, candidate, pass = 1)
    Else
        ' Counts may update during paste. Use native identity now; verify the
        ' untouched original counts after the single target-sheet rebuild.
        Set identity = CloneRecord(candidate)
        identity("Dimensions") = original("Dimensions")
        identity("ApprovedOmissions") = ApprovedOmissions(original)
        SameCopiedViewFingerprint = SameViewFingerprint(original, identity, True)
    End If
End Function

Private Function SameViewFingerprint(ByVal a As Object, ByVal b As Object, _
    Optional ByVal ignorePlacement As Boolean = False) As Boolean
    SameViewFingerprint = False
    If CLng(a("Type")) <> CLng(b("Type")) Then Exit Function
    If Not SameText(CStr(a("Model")), CStr(b("Model"))) Then Exit Function
    If StrComp(CStr(a("Configuration")), CStr(b("Configuration")), vbBinaryCompare) <> 0 Then Exit Function
    If CStr(a("Orientation")) <> CStr(b("Orientation")) Then Exit Function
    If Not ignorePlacement Then
        If Not NearValue(CDbl(a("X")), CDbl(b("X")), GEOM_TOL) Then Exit Function
        If Not NearValue(CDbl(a("Y")), CDbl(b("Y")), GEOM_TOL) Then Exit Function
        If Not NearValue(CDbl(a("Scale")), CDbl(b("Scale")), VALUE_TOL) Then Exit Function
        If Not NearValue(CDbl(a("Angle")), CDbl(b("Angle")), VALUE_TOL) Then Exit Function
    End If
    If RequiredDimensionCount(a) <> RequiredDimensionCount(b) Then Exit Function
    If CBool(a("Reversed")) <> CBool(b("Reversed")) Then Exit Function
    If CBool(a("Partial")) <> CBool(b("Partial")) Then Exit Function
    If CBool(a("SurfaceOnly")) <> CBool(b("SurfaceOnly")) Then Exit Function
    SameViewFingerprint = True
End Function

Private Sub LogViewFingerprint(ByVal context As String, ByVal rec As Object)
    Dim field As Variant
    LogLine context & ": view=" & CStr(rec("Name")) & "; sheet=" & CStr(rec("Sheet"))
    For Each field In Array("Parent", "Type", "Model", "Configuration", "Orientation", _
        "X", "Y", "Scale", "Angle", "Dimensions", "Reversed", "Partial", "SurfaceOnly")
        LogLine "  " & CStr(field) & "=[" & CStr(rec(field)) & "]"
    Next field
End Sub

Private Sub VerifyStructure(ByVal expected As Object, ByVal actual As Object, ByVal stage As String)
    Dim key As Variant, a As Object, b As Object
    Require expected("Views").Count = actual("Views").Count, stage & ": ���������� ����� ����� �����."
    For Each key In expected("Views").Keys
        Require actual("Views").Exists(CStr(key)), stage & ": ������� ��� " & CStr(key)
        Set a = expected("Views")(CStr(key))
        Set b = actual("Views")(CStr(key))
        Require CLng(a("Type")) = CLng(b("Type")), stage & ": ��������� ��� " & CStr(key)
        Require SameText(CStr(a("Parent")), CStr(b("Parent"))), stage & ": �������� ����� �������� " & CStr(key)
        Require SameText(CStr(a("Model")), CStr(b("Model"))), stage & ": �������� ������ " & CStr(key)
        Require CStr(a("Configuration")) = CStr(b("Configuration")), stage & ": �������� ������������ " & CStr(key)
        Require RequiredDimensionCount(a) = RequiredDimensionCount(b), stage & ": ����� �������� ���� " & CStr(key) & _
            "; ���������=" & CStr(a("Dimensions")) & "; ����������=" & CStr(b("Dimensions"))
    Next key
End Sub

Private Function PropertyViewReadbackMatches(ByVal expectedSheet As Object, _
    ByVal actualSheet As Object, ByVal actualViews As Object) As Boolean
    Dim desired As String, resolved As String, desiredView As Object, resolvedView As Object
    ' Only a local default label may replace a requested explicit view.
    If CBool(expectedSheet("SameCustomProp")) Or CBool(actualSheet("SameCustomProp")) Then Exit Function
    Select Case LCase$(Trim$(CStr(actualSheet("PropertyView"))))
        Case "", "default", "�� ���������"
        Case Else
            Exit Function
    End Select
    desired = CStr(expectedSheet("PropertyView"))
    resolved = CStr(actualSheet("EffectivePropertyView"))
    If actualViews.Exists(desired) = False Then Exit Function
    If actualViews.Exists(resolved) = False Then Exit Function
    Set desiredView = actualViews(desired)
    Set resolvedView = actualViews(resolved)
    If SameText(CStr(desiredView("Model")), CStr(expectedSheet("PropertyModel"))) = False Then Exit Function
    If CStr(desiredView("Configuration")) <> CStr(expectedSheet("PropertyConfiguration")) Then Exit Function
    If SameText(CStr(resolvedView("Model")), CStr(expectedSheet("PropertyModel"))) = False Then Exit Function
    If CStr(resolvedView("Configuration")) <> CStr(expectedSheet("PropertyConfiguration")) Then Exit Function
    If SameText(CStr(actualSheet("PropertyModel")), CStr(expectedSheet("PropertyModel"))) = False Then Exit Function
    If CStr(actualSheet("PropertyConfiguration")) <> CStr(expectedSheet("PropertyConfiguration")) Then Exit Function
    PropertyViewReadbackMatches = True
End Function

Private Sub VerifyDrawing(ByVal expected As Object, ByVal actual As Object, ByVal stage As String)
    Dim key As Variant, field As Variant, a As Object, b As Object, i As Long
    VerifyStructure expected, actual, stage
    Require expected("Sheets").Count = actual("Sheets").Count, stage & ": ����� ������ �� ���������."
    For i = 1 To expected("Order").Count
        Require SameText(CStr(expected("Order")(i)), CStr(actual("Order")(i))), stage & ": ������� ������� ������."
    Next i
    For Each key In expected("Sheets").Keys
        Require actual("Sheets").Exists(CStr(key)), stage & ": ������� ���� " & CStr(key)
        Set a = expected("Sheets")(CStr(key))
        Set b = actual("Sheets")(CStr(key))
        For Each field In Array("Width", "Height")
            Require NearValue(CDbl(a(field)), CDbl(b(field)), PAPER_TOL), stage & ": ������ ������ ����� " & CStr(key)
        Next field
        Require CDbl(a("Scale2")) > 0 And CDbl(b("Scale2")) > 0, "������������ ������� �����."
        Require NearValue(CDbl(a("Scale1")) / CDbl(a("Scale2")), _
            CDbl(b("Scale1")) / CDbl(b("Scale2")), SCALE_TOL), stage & ": ������� ����� " & CStr(key)
        Require CBool(a("FirstAngle")) = CBool(b("FirstAngle")), stage & ": ������� �������� ����� " & CStr(key)
        Require CBool(a("SameCustomProp")) = CBool(b("SameCustomProp")), _
            stage & ": ����� ��������� ������� ����� " & CStr(key)
        LogLine "PROPERTY SOURCE CHECK [" & stage & "]: sheet=" & CStr(key) & _
            "; inherited=" & CStr(a("SameCustomProp")) & "; expectedModel=[" & CStr(a("PropertyModel")) & _
            "]; actualModel=[" & CStr(b("PropertyModel")) & "]; expectedConfig=[" & _
            CStr(a("PropertyConfiguration")) & "]; actualConfig=[" & CStr(b("PropertyConfiguration")) & "]"
        Require SameText(CStr(a("PropertyModel")), CStr(b("PropertyModel"))), _
            stage & ": ���������� ������ ��������� ������� ����� " & CStr(key)
        Require CStr(a("PropertyConfiguration")) = CStr(b("PropertyConfiguration")), _
            stage & ": ���������� ������������ ��������� ������� ����� " & CStr(key)
        If CBool(a("SameCustomProp")) = False And _
            Not SameText(CStr(a("PropertyView")), CStr(b("PropertyView"))) Then
            If PropertyViewReadbackMatches(a, b, actual("Views")) Then
                LogLine "PROPERTY VIEW equivalent default [" & stage & "]: sheet=" & CStr(key) & _
                    "; requested=[" & CStr(a("PropertyView")) & "]; readback=[" & CStr(b("PropertyView")) & _
                    "]; effective=[" & CStr(b("EffectivePropertyView")) & "]"
            Else
                LogLine "PROPERTY VIEW mismatch [" & stage & "]: sheet=" & CStr(key) & _
                    "; expected=[" & CStr(a("PropertyView")) & "]; actual=[" & CStr(b("PropertyView")) & "]"
                Require False, stage & ": ��� ������� ����� " & CStr(key) & _
                    "; ���������=[" & CStr(a("PropertyView")) & "]; ����������=[" & CStr(b("PropertyView")) & "]"
            End If
        End If
        Require CBool(a("FormatVisible")) = CBool(b("FormatVisible")), stage & ": ��������� ������� " & CStr(key)
        VerifyAnnotations a, b, stage & ": ���� " & CStr(key)
    Next key
    For Each key In expected("Views").Keys
        Set a = expected("Views")(CStr(key))
        Set b = actual("Views")(CStr(key))
        Require SameText(CStr(a("Sheet")), CStr(b("Sheet"))), stage & ": ��� �� �������� ����� " & CStr(key)
        If Not SameViewFingerprint(a, b, True) Then
            LogViewFingerprint stage & " expected", a
            LogViewFingerprint stage & " actual", b
            Require False, stage & ": ���������/��������� ���� �� ���������: " & CStr(key)
        End If
        Require NearValue(CDbl(a("X")), CDbl(b("X")), POSITION_TOL) And _
            NearValue(CDbl(a("Y")), CDbl(b("Y")), POSITION_TOL), stage & ": �������� ���� ��������� 30 ��: " & CStr(key)
        Require NearValue(CDbl(a("Scale")), CDbl(b("Scale")), SCALE_TOL), stage & ": ������� ���� " & CStr(key)
        Require NearValue(CDbl(a("Angle")), CDbl(b("Angle")), ANGLE_TOL), stage & ": ���� ���� " & CStr(key)
        For Each field In Array("SheetScale", "ParentScale", "Locked", "Alignment")
            If CLng(a(field)) <> CLng(b(field)) Then LogLine "LAYOUT WARNING: " & CStr(key) & "; field=" & CStr(field)
        Next field
        For Each field In Array("Suppressed", "Visible")
            If CLng(a(field)) <> CLng(b(field)) Then
                LogLine "VIEW FIELD mismatch [" & stage & "]: view=" & CStr(key) & _
                    "; sheet=" & CStr(b("Sheet")) & "; field=" & CStr(field) & _
                    "; expected=" & CLng(a(field)) & "; actual=" & CLng(b(field))
            End If
            Require CLng(a(field)) = CLng(b(field)), stage & ": " & CStr(field) & " / " & CStr(key) & _
                "; ���������=" & CLng(a(field)) & "; ����������=" & CLng(b(field))
        Next field
        If CLng(a("Hatches")) <> CLng(b("Hatches")) Then
            LogLine "HATCH COUNT changed: view=" & CStr(key) & "; expected=" & CStr(a("Hatches")) & "; actual=" & CStr(b("Hatches"))
        End If
        Require HatchContentPreserved(CLng(a("Hatches")), CLng(b("Hatches"))), stage & ": ������� ��������� ������� " & CStr(key)
        If CDbl(a("BoxWidth")) > GEOM_TOL And CDbl(a("BoxHeight")) > GEOM_TOL Then
            Require CDbl(b("BoxWidth")) > GEOM_TOL And CDbl(b("BoxHeight")) > GEOM_TOL, _
                stage & ": ������ ��������� ���� " & CStr(key)
        End If
        Require CStr(a("Label")) = CStr(b("Label")), stage & ": ���������� ����������� ������� " & CStr(key)
        VerifyAnnotations a, b, stage & ": ��� " & CStr(key)
        If Len(CStr(a("Parent"))) > 0 Then LogLine "LINK OK [" & CStr(key) & "] -> [" & CStr(b("Parent")) & "]"
    Next key
    LogLine "AUDIT OK " & stage & "; sheets=" & actual("Sheets").Count & "; views=" & actual("Views").Count
End Sub

Private Function HatchContentPreserved(ByVal expected As Long, ByVal actual As Long) As Boolean
    If expected < 0 Or actual < 0 Then Exit Function
    If expected = 0 Then
        HatchContentPreserved = True
    Else
        HatchContentPreserved = (actual > 0)
    End If
End Function

Private Sub VerifyAnnotations(ByVal a As Object, ByVal b As Object, ByVal context As String)
    Require RequiredDimensionCount(a) = RequiredDimensionCount(b), context & ": ����� �������� �� ���������."
    Require CLng(a("NoteCount")) = CLng(b("NoteCount")), context & ": ����� ������� �� ���������."
    Require CLng(a("Annotations")) = CLng(b("Annotations")) Or _
        CLng(a("Annotations")) - CLng(b("Annotations")) = ApprovedOmissions(a) - ApprovedOmissions(b), _
        context & ": ����� ��������� �� ���������."
    Require CLng(b("Dangling")) <= CLng(a("Dangling")), context & ": ��������� ������� ���������."
    VerifyLinkedNotes a("LinkedNotes"), b("LinkedNotes"), context
End Sub

Private Sub InvalidateViewIndex()
    Set viewIndex = Nothing
    Set indexedModel = Nothing
End Sub

Private Function FindView(ByVal model As SldWorks.ModelDoc2, ByVal name As String) As SldWorks.View
    Dim drawing As SldWorks.DrawingDoc, groups As Variant, group As Variant
    Dim view As SldWorks.View, i As Long, j As Long, viewName As String
    If Not indexedModel Is Nothing Then
        If Not indexedModel Is model Then InvalidateViewIndex
    End If
    If viewIndex Is Nothing Then
        Set drawing = model
        Set viewIndex = NewDictionary()
        Set indexedModel = model
        groups = drawing.GetViews
        If IsArray(groups) Then
            For i = LBound(groups) To UBound(groups)
                group = groups(i)
                If IsArray(group) Then
                    For j = LBound(group) + 1 To UBound(group)
                        Set view = group(j)
                        If Not view Is Nothing Then
                            viewName = view.GetName2
                            Require Not viewIndex.Exists(viewName), "������������� ��� ���� � �������: " & viewName
                            viewIndex.Add viewName, view
                        End If
                    Next j
                End If
            Next i
        End If
    End If
    If viewIndex.Exists(name) Then Set FindView = viewIndex(name)
End Function

Private Function ViewSheetName(ByVal view As SldWorks.View) As String
    Dim sheet As SldWorks.Sheet
    Set sheet = view.Sheet
    Require Not sheet Is Nothing, "�� ��������� ���� ���� " & view.GetName2
    ViewSheetName = sheet.GetName
End Function

Private Sub RebuildDrawing(ByVal model As SldWorks.ModelDoc2, ByVal selectedSheets As Object)
    Dim drawing As SldWorks.DrawingDoc, names As Variant, name As Variant
    Dim sheet As SldWorks.Sheet, originalSheet As String
    Dim forced As Boolean, pending As Object, key As Variant
    Dim started As Double
    Require Not model Is Nothing, "�������� ��� ������������ �� �����."
    Require model.GetType = swDocDRAWING, "������������ ��������� ������ ��� �������."
    Require Not selectedSheets Is Nothing, "�� ������ ����� ��� ������������."
    If selectedSheets.Count = 0 Then Exit Sub
    RequireOwnedPath model.GetPathName
    RequireActive model
    Set drawing = model
    Set sheet = drawing.GetCurrentSheet
    Require Not sheet Is Nothing, "�� ������� ������� ���� ��� ������������."
    originalSheet = sheet.GetName
    names = drawing.GetSheetNames
    Require HasVectorElements(names, 1), "�� ������� ������ ������ ��� ������������."
    Set pending = NewDictionary()
    For Each key In selectedSheets.Keys
        pending(CStr(selectedSheets(key))) = True
    Next key
    For Each name In names
        If Not pending.Exists(CStr(name)) Then GoTo NextRebuildSheet
        started = Timer
        EnsureSheetActive model, CStr(name), "RebuildDrawing"
        model.ClearSelection2 True
        LogLine "REBUILD begin: doc=" & model.GetPathName & "; sheet=" & CStr(name)
        ' Never call ForceRebuild3 on ReferencedDocument or an assembly.
        InvalidateViewIndex
        If FORCE_ALL_REBUILDS Then
            forced = model.ForceRebuild3(False)
            LogLine "REBUILD mode=force; result=" & CStr(forced)
        Else
            forced = model.EditRebuild3()
            LogLine "REBUILD mode=edit; result=" & CStr(forced)
            If forced Then
                ' Final audit remains mandatory; success alone does not prove hatch rendering.
            Else
                InvalidateViewIndex
                forced = model.ForceRebuild3(False)
                LogLine "REBUILD fallback=force; result=" & CStr(forced)
            End If
        End If
        Require forced, "������������ �� ������������: ����=" & CStr(name) & "; ��������=" & model.GetPathName
        Set sheet = drawing.GetCurrentSheet
        Require Not sheet Is Nothing, "������� ������� ���� ����� ������������."
        Require SameText(sheet.GetName, CStr(name)), "����� ������������ ��������� �������� ����."
        LogLine "REBUILD elapsed_seconds=" & Format$(ElapsedSeconds(started), "0.000")
        pending.Remove CStr(name)
NextRebuildSheet:
    Next name
    Require pending.Count = 0, "�� ������� ��� ����� ��� ������������."
    EnsureSheetActive model, originalSheet, "RebuildDrawing restore"
End Sub

Private Sub CheckSavedInput(ByVal path As String)
    Dim model As SldWorks.ModelDoc2
    Require fsoRun.FileExists(path), "���� �� ������: " & path
    Require LCase$(fsoRun.GetExtensionName(path)) = "slddrw", "����� ���� .slddrw: " & path
    Set model = swApp.GetOpenDocumentByName(path)
    If Not model Is Nothing Then
        If model.GetSaveFlag Then LogLine "INPUT live unsaved changes accepted: " & path
    End If
End Sub

Private Function PrepareMainDrawing(ByVal path As String) As SldWorks.ModelDoc2
    Dim model As SldWorks.ModelDoc2
    Dim fileAttributes As Long
    CheckSavedInput path
    fileAttributes = CLng(fsoRun.GetFile(path).Attributes)
    If (fileAttributes And vbReadOnly) <> 0 Then
        Require False, "�������� ���� �������� ������ ��� ������."
    End If
    Set model = swApp.GetOpenDocumentByName(path)
    ' Main-file backup disabled at the user's request.
    publishedDrawingPath = path
    If model Is Nothing Then Set model = OpenWorkingDrawing(path)
    Require model.IsOpenedReadOnly = False, "�������� ������ ������ ������ ��� ������; �������� ��� ��� ������."
    RequireActive model
    ' The saved main sheets have not been edited. Preserve their snapshot;
    ' rebuild imported sheets once after restoration, not all existing sheets.
    Set expectedResult = CaptureDrawing(model)
    Set PrepareMainDrawing = model
End Function

Private Function CloneInput(ByVal path As String, ByVal copyPath As String, _
    ByVal original As SldWorks.ModelDoc2, ByVal baseline As Object, _
    ByVal originalSheet As String) As SldWorks.ModelDoc2
    Dim copy As SldWorks.ModelDoc2, actual As Object
    Dim errors As Long, warnings As Long, e As Long, message As String
    Dim oldFolder As String, copied As Boolean
    On Error GoTo Failed
    CheckSavedInput path
    RequireOwnedPath copyPath
    Require Not fsoRun.FileExists(copyPath), "������� ����� ��� ����������: " & copyPath
    Require Not original Is Nothing, "�� ������� �������� �������� ������."
    Require Not baseline Is Nothing, "�� ������� �������� ������."
    Require SameText(NormalizePath(original.GetPathName), NormalizePath(path)), "������� ������ �������� ������."
    LogLine "CLONE baseline reused: " & path
    ' A byte copy preserves the full native graph and avoids changing any source
    ' references through SaveAs. Keep referenced models loaded from the original.
    LogLine "CLONE file copy begin: " & copyPath
    If original.GetSaveFlag Then
        copied = original.Extension.SaveAs(copyPath, 0, swSaveAsOptions_Silent Or swSaveAsOptions_Copy, Nothing, errors, warnings)
        Require copied And errors = 0, "�� ������� ������� ����� �������������� ���������: " & errors
        Require SameText(NormalizePath(original.GetPathName), NormalizePath(path)), "��������� ���� ��������� ���������."
        Require fsoRun.FileExists(copyPath), "������� ����� ��������� �����������."
    Else
        fsoRun.CopyFile path, copyPath, False
    End If
    LogLine "CLONE file copy complete: bytes=" & fsoRun.GetFile(copyPath).Size
    SetAttr copyPath, vbNormal
    oldFolder = swApp.GetCurrentWorkingDirectory
    EnsureWorkingDirectory fsoRun.GetParentFolderName(path), "CloneInput source"
    Set copy = OpenWorkingDrawing(copyPath)
    EnsureWorkingDirectory oldFolder, "CloneInput restore"
    oldFolder = ""
    LogLine "CLONE copy: " & copyPath
    Set actual = CaptureDrawing(copy)
    VerifyDrawing baseline, actual, "CLONE " & path
    EnsureSheetActive original, originalSheet, "CloneInput restore"
    Set CloneInput = copy
    Exit Function
Failed:
    e = Err.Number
    message = Err.Description
    On Error Resume Next
    If Len(oldFolder) > 0 Then EnsureWorkingDirectory oldFolder, "CloneInput failure restore"
    If Len(originalSheet) > 0 Then EnsureSheetActive original, originalSheet, "CloneInput restore"
    CloseOwnedDrawing copy
    On Error GoTo 0
    Err.Raise e, "CloneInput", message
End Function

Private Function OpenWorkingDrawing(ByVal path As String) As SldWorks.ModelDoc2
    Dim model As SldWorks.ModelDoc2, errors As Long, warnings As Long
    RequireOwnedPath path
    LogLine "OPEN begin: " & path
    Set model = swApp.OpenDoc6(path, swDocDRAWING, swOpenDocOptions_Silent, "", errors, warnings)
    LogLine "OPEN " & path & "; errors=" & errors & "; warnings=" & warnings
    Require Not model Is Nothing, "�� ������� ������� �����. ���: " & errors
    Require model.GetType = swDocDRAWING, "������� ����� �� �������� ��������."
    Require SameText(NormalizePath(model.GetPathName), NormalizePath(path)), "SOLIDWORKS ������ ������ ��������."
    Set OpenWorkingDrawing = model
End Function

Private Sub EnsureWorkingDirectory(ByVal folder As String, ByVal context As String)
    Dim requested As String, beforeFolder As String, afterFolder As String
    Dim apiResult As Boolean
    Require Len(folder) > 0, "������ ������� ����� [" & context & "]."
    Require fsoRun.FolderExists(folder), "������� ����� �� ���������� [" & context & "]: " & folder
    requested = fsoRun.GetFolder(folder).Path
    beforeFolder = swApp.GetCurrentWorkingDirectory
    If SameFolder(beforeFolder, requested) Then
        LogLine "CWD CURRENT [" & context & "] folder=" & beforeFolder
        Exit Sub
    End If
    apiResult = swApp.SetCurrentWorkingDirectory(requested)
    afterFolder = swApp.GetCurrentWorkingDirectory
    LogLine "CWD SET [" & context & "] requested=" & requested & _
        "; before=" & beforeFolder & "; api=" & CStr(apiResult) & "; current=" & afterFolder
    Require SameFolder(afterFolder, requested), "�� ������ ������� ����� [" & context & _
        "]; requested=" & requested & "; before=" & beforeFolder & _
        "; current=" & afterFolder & "; API=" & CStr(apiResult)
End Sub

Private Function SameFolder(ByVal first As String, ByVal second As String) As Boolean
    ' GetFolder resolves equivalent existing folder spellings without changing CWD.
    If Len(first) = 0 Or Len(second) = 0 Then Exit Function
    If Not fsoRun.FolderExists(first) Then Exit Function
    If Not fsoRun.FolderExists(second) Then Exit Function
    SameFolder = SameText(fsoRun.GetFolder(first).Path, fsoRun.GetFolder(second).Path)
End Function

Private Sub EnsureSheetActive(ByVal model As SldWorks.ModelDoc2, ByVal sheetName As String, ByVal context As String)
    Dim drawing As SldWorks.DrawingDoc, sheet As SldWorks.Sheet
    Dim beforeName As String, afterName As String, apiResult As Boolean
    RequireActive model
    Set drawing = model
    Set sheet = drawing.GetCurrentSheet
    If Not sheet Is Nothing Then beforeName = sheet.GetName
    ' ActivateSheet is unnecessary if the requested sheet is already current.
    If SameText(beforeName, sheetName) Then
        drawing.EditSheet
        LogLine "SHEET CURRENT [" & context & "] doc=" & model.GetPathName & "; sheet=" & beforeName
        Exit Sub
    End If
    drawing.EditSheet
    InvalidateViewIndex
    apiResult = drawing.ActivateSheet(sheetName)
    Set sheet = drawing.GetCurrentSheet
    If Not sheet Is Nothing Then afterName = sheet.GetName
    LogLine "SHEET ACTIVATE [" & context & "] doc=" & model.GetPathName & _
        "; requested=" & sheetName & "; before=" & beforeName & _
        "; api=" & CStr(apiResult) & "; current=" & afterName
    ' Verify the actual postcondition even when the API reports success.
    Require SameText(afterName, sheetName), "�� ����������� ���� " & sheetName & _
        " [" & context & "]; �������=" & afterName & "; API=" & CStr(apiResult) & _
        "; ��������=" & model.GetPathName
    drawing.EditSheet
End Sub

Private Sub RequireActive(ByVal model As SldWorks.ModelDoc2)
    Dim active As SldWorks.ModelDoc2, errors As Long
    Require Not model Is Nothing, "�������� �� �����."
    Set active = swApp.ActiveDoc
    If Not active Is Nothing Then
        If SameText(NormalizePath(active.GetPathName), NormalizePath(model.GetPathName)) Then
            SuspendDocumentUI model
            Exit Sub
        End If
    End If
    InvalidateViewIndex
    Set active = swApp.ActivateDoc3(model.GetTitle, False, swDontRebuildActiveDoc, errors)
    Require Not active Is Nothing, "�� ������� ������������ " & model.GetTitle & "; ���=" & errors
    Require SameText(NormalizePath(active.GetPathName), NormalizePath(model.GetPathName)), _
        "����������� ������ �������� � ����� �� ������."
    SuspendDocumentUI model
End Sub

Private Sub CloseOwnedDrawing(ByRef model As SldWorks.ModelDoc2)
    If model Is Nothing Then Exit Sub
    RequireOwnedPath model.GetPathName
    InvalidateViewIndex
    BeforeCloseUI model
    swApp.CloseDoc model.GetTitle
    Set model = Nothing
End Sub

Private Sub RequireOwnedPath(ByVal path As String)
    Dim root As String, full As String
    Require Len(runFolder) > 0, "������� ����� �� �������."
    root = NormalizePath(fsoRun.GetAbsolutePathName(runFolder)) & "\"
    full = NormalizePath(fsoRun.GetAbsolutePathName(path))
    If Len(publishedDrawingPath) > 0 Then
        If SameText(full, NormalizePath(fsoRun.GetAbsolutePathName(publishedDrawingPath))) Then Exit Sub
    End If
    Require Left$(full, Len(root)) = root, "��������� �������� ���� ��� ����� �������: " & path
End Sub

Private Sub InitRunFolder(ByVal mainPath As String)
    Dim base As String, parent As String, token As String, suffix As Long
    base = fsoRun.GetParentFolderName(mainPath)
    Require Len(base) > 0, "�� ���������� ����� ��������� �������."
    Require fsoRun.FolderExists(base), "�� ������� ����� ��������� �������: " & base
    parent = fsoRun.BuildPath(base, "runs")
    If fsoRun.FolderExists(parent) = False Then fsoRun.CreateFolder parent
    token = Format$(Now, "yyyymmdd_hhnnss")
    runToken = token
    runFolder = fsoRun.BuildPath(parent, runToken)
    Do While fsoRun.FolderExists(runFolder)
        suffix = suffix + 1
        runToken = token & "_" & CStr(suffix)
        runFolder = fsoRun.BuildPath(parent, runToken)
    Loop
    fsoRun.CreateFolder runFolder
    Set logStream = fsoRun.CreateTextFile(runFolder & "\merge.log", False, True)
End Sub

Private Sub WriteStatus(ByVal status As String, ByVal message As String)
    Dim stream As Object
    If Len(runFolder) = 0 Then Exit Sub
    Set stream = fsoRun.CreateTextFile(runFolder & "\STATUS.txt", True, True)
    stream.WriteLine BUILD_ID
    stream.WriteLine status
    stream.WriteLine message
    stream.Close
End Sub

Private Sub WriteManifest(ByVal snapshot As Object, ByVal path As String)
    Dim stream As Object, key As Variant, rec As Object
    RequireOwnedPath path
    Set stream = fsoRun.CreateTextFile(path, False, True)
    stream.WriteLine "sheet" & vbTab & "view" & vbTab & "type" & vbTab & "parent" & vbTab & _
        "model" & vbTab & "configuration" & vbTab & "x_m" & vbTab & "y_m" & vbTab & "scale"
    For Each key In snapshot("Views").Keys
        Set rec = snapshot("Views")(CStr(key))
        stream.WriteLine CStr(rec("Sheet")) & vbTab & CStr(key) & vbTab & CStr(rec("Type")) & vbTab & _
            CStr(rec("Parent")) & vbTab & CStr(rec("Model")) & vbTab & CStr(rec("Configuration")) & vbTab & _
            CStr(rec("X")) & vbTab & CStr(rec("Y")) & vbTab & CStr(rec("Scale"))
    Next key
    stream.Close
End Sub

Private Sub LogLine(ByVal message As String)
    Debug.Print message
    If Not logStream Is Nothing Then logStream.WriteLine Format$(Now, "hh:nn:ss") & " " & message
End Sub

Private Function FlagValue(ByVal value As Boolean) As Boolean
    ' Return a canonical VBA Boolean (-1/0), even if COM supplied +1 for True.
    If value Then
        FlagValue = True
    Else
        FlagValue = False
    End If
End Function

Private Sub Require(ByVal condition As Boolean, ByVal message As String)
    ' Test truth directly: Not is a bitwise operation on raw COM Boolean values.
    If condition Then Exit Sub
    Err.Raise vbObjectError + 1600, BUILD_ID, message
End Sub

Private Function NewDictionary() As Object
    Dim result As Object
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    Set NewDictionary = result
End Function

Private Function CloneRecord(ByVal source As Object) As Object
    Dim result As Object, key As Variant
    Set result = NewDictionary()
    For Each key In source.Keys
        result.Add CStr(key), source(key)
    Next key
    Set CloneRecord = result
End Function

Private Function SameText(ByVal a As String, ByVal b As String) As Boolean
    SameText = (StrComp(a, b, vbTextCompare) = 0)
End Function

Private Function NormalizePath(ByVal value As String) As String
    NormalizePath = LCase$(Replace(value, "/", "\"))
End Function

Private Function HasVectorElements(ByVal values As Variant, ByVal minimum As Long) As Boolean
    On Error GoTo InvalidVector
    If Not IsArray(values) Then Exit Function
    If LBound(values) <> 0 Then Exit Function
    If UBound(values) < minimum - 1 Then Exit Function
    HasVectorElements = True
    Exit Function
InvalidVector:
    HasVectorElements = False
End Function

Private Function NearValue(ByVal a As Double, ByVal b As Double, ByVal tolerance As Double) As Boolean
    NearValue = (Abs(a - b) <= tolerance)
End Function

' Only sources whose parent chains cross sheets need an editable private copy.
Private Function PrepareSource(ByVal path As String, ByVal fileIndex As Long, _
    ByRef snapshot As Object, ByRef direct As Boolean, ByRef opened As Boolean, _
    ByRef initialSheet As String) As SldWorks.ModelDoc2
    Dim model As SldWorks.ModelDoc2, copy As SldWorks.ModelDoc2, drawing As SldWorks.DrawingDoc
    Dim key As Variant, order As Collection, needsCopy As Boolean
    Dim errors As Long, warnings As Long, number As Long, message As String
    On Error GoTo Failed
    direct = True
    opened = False
    CheckSavedInput path
    Set model = swApp.GetOpenDocumentByName(path)
    If model Is Nothing Then
        Set model = swApp.OpenDoc6(path, swDocDRAWING, swOpenDocOptions_Silent Or swOpenDocOptions_ReadOnly, "", errors, warnings)
        opened = Not model Is Nothing
    End If
    Require Not model Is Nothing, "�� ������ ��������: " & path & "; ���=" & errors
    Set drawing = model
    initialSheet = drawing.GetCurrentSheet.GetName
    Set snapshot = CaptureDrawing(model)
    Set order = DependencyOrder(snapshot("Views"))
    For Each key In order
        If Not SameText(CStr(snapshot("Views")(CStr(key))("Sheet")), _
            CStr(snapshot("Views")(CStr(key))("Carrier"))) Then needsCopy = True
    Next key
    If needsCopy Then
        Set copy = CloneInput(path, runFolder & "\SOURCE_" & runToken & "_" & Format$(fileIndex, "0000") & ".slddrw", _
            model, snapshot, initialSheet)
        ReleaseSource model, True, opened, initialSheet
        Set model = copy
        Set copy = Nothing
        direct = False
        opened = False
        ' CloneInput verified the byte copy against the original snapshot.
        LogLine "SOURCE MODE private copy: cross-sheet dependent views; " & path
    Else
        LogLine "SOURCE MODE direct read-only transfer: " & path
    End If
    Set PrepareSource = model
    Exit Function
Failed:
    number = Err.Number
    message = Err.Description
    On Error Resume Next
    ReleaseSource model, direct, opened, initialSheet
    CloseOwnedDrawing copy
    On Error GoTo 0
    Err.Raise number, "PrepareSource", message
End Function

Private Sub ReleaseSource(ByRef model As SldWorks.ModelDoc2, ByVal direct As Boolean, _
    ByVal opened As Boolean, ByVal initialSheet As String)
    If model Is Nothing Then Exit Sub
    If direct Then
        If opened Then
            InvalidateViewIndex
    BeforeCloseUI model
    swApp.CloseDoc model.GetTitle
        Else
            If Len(initialSheet) > 0 Then EnsureSheetActive model, initialSheet, "ReleaseSource restore"
            model.ClearSelection2 True
        End If
        Set model = Nothing
    Else
        CloseOwnedDrawing model
    End If
End Sub


Private Function LocalizeTargetPropertyView(ByVal snapshot As Object, ByVal sourceSheet As String, _
    ByVal targetSheet As String, ByVal requested As String, ByVal helpers As Object) As String
    Dim view As SldWorks.View, sourceView As Object, sheetRec As Object
    Dim name As String, modelPath As String, configuration As String
    RequireOwnedPath targetModel.GetPathName
    Set sheetRec = snapshot("Sheets")(sourceSheet)
    If Len(CStr(sheetRec("PropertyModel"))) = 0 Then
        LocalizeTargetPropertyView = requested
        Exit Function
    End If
    Set view = FindView(targetModel, requested)
    Require Not view Is Nothing, "�� ������ �������� �������: " & requested
    If SameText(ViewSheetName(view), targetSheet) Then
        LocalizeTargetPropertyView = requested
        Exit Function
    End If
    Set sheetRec = snapshot("Sheets")(sourceSheet)
    Set sourceView = snapshot("Views")(CStr(sheetRec("EffectivePropertyView")))
    modelPath = CStr(sheetRec("PropertyModel"))
    configuration = CStr(sheetRec("PropertyConfiguration"))
    Require Len(modelPath) > 0 And Len(CStr(sourceView("Orientation"))) > 0, _
        "������������ ������ ��� ���������� ��������� �������: " & targetSheet
    EnsureSheetActive targetModel, targetSheet, "Local property carrier"
    targetModel.ClearSelection2 True
    ' Create geometry from the required model, not from the detail already on this sheet.
    InvalidateViewIndex
    Set view = targetDraw.CreateDrawViewFromModelView3(modelPath, CStr(sourceView("Orientation")), _
        CDbl(sheetRec("Width")) / 2#, CDbl(sheetRec("Height")) / 2#, 0#)
    Require Not view Is Nothing, "�� ������ ��������� ��� �������: " & targetSheet
    name = view.GetName2
    view.ReferencedConfiguration = configuration
    view.UseSheetScale = 0
    view.UseParentScale = False
    view.ScaleDecimal = 0.01
    view.SetVisible False, False
    targetDraw.HiddenViewsVisible = False
    Require FlagValue(targetDraw.HiddenViewsVisible) = False, "�� �������� ����� ������� ��������� �����."
    Require FlagValue(view.GetVisible) = False, "�� ����� ��������� ���: " & name
    Require SameText(ViewSheetName(view), targetSheet), "��������� ��� ������ �� ������ �����."
    Require SameText(NormalizePath(view.GetReferencedModelName), modelPath), "�������� ������ ���������� ����."
    Require view.ReferencedConfiguration = configuration, "�������� ������������ ���������� ����."
    helpers.Add name, sheetRec
    LogLine "PROPERTY CARRIER created: sheet=" & targetSheet & "; view=" & name & "; hidden=True; model=" & modelPath
    LocalizeTargetPropertyView = name
End Function

' Keep live component links. Never substitute evaluated text for a property expression.
Private Function CaptureLinkedNotes(ByVal view As SldWorks.View) As Collection
    Dim result As Collection, notes As Variant, i As Long
    Dim note As SldWorks.Note, annotation As SldWorks.Annotation, rec As Object
    Dim raw As String, p As Variant
    Set result = New Collection
    notes = view.GetNotes
    If IsArray(notes) Then
        For i = LBound(notes) To UBound(notes)
            Set note = notes(i)
            Require Not note Is Nothing, "������ ������ ������� ��� ������."
            raw = note.PropertyLinkedText
            If IsComponentPropertyNote(raw) Then
                Set annotation = note.GetAnnotation
                Require Not annotation Is Nothing, "�� ��������� ��������� ��������� �������."
                Set rec = NewDictionary()
                rec.Add "Name", note.GetName
                rec.Add "Link", raw
                rec.Add "Text", note.GetText
                rec.Add "Layer", annotation.Layer
                rec.Add "Visible", CLng(annotation.Visible)
                rec.Add "Attachments", NoteAttachmentSignature(annotation, view)
                p = annotation.GetPosition
                Require HasVectorElements(p, 3), "��� ��������� ��������� �������: " & note.GetName
                rec.Add "X", CDbl(p(0))
                rec.Add "Y", CDbl(p(1))
                result.Add rec
            End If
        Next i
    Else
        Require view.GetNoteCount = 0, "�� �������� ������ �������: " & view.GetName2
    End If
    Set CaptureLinkedNotes = result
End Function

Private Function IsComponentPropertyNote(ByVal raw As String) As Boolean
    IsComponentPropertyNote = (InStr(1, raw, "$PRPSMODEL:", vbTextCompare) > 0 And _
        InStr(1, raw, "$COMP:" & Chr$(34), vbTextCompare) > 0)
End Function

Private Function NoteAttachmentSignature(ByVal annotation As SldWorks.Annotation, ByVal view As SldWorks.View) As String
    Dim attached As Variant, i As Long, entity As SldWorks.Entity
    Dim obj As Object, component As SldWorks.Component2, item As String
    Dim drawingComponent As SldWorks.DrawingComponent, parts() As String, j As Long, tmp As String
    Dim count As Long
    count = annotation.GetAttachedEntityCount3
    NoteAttachmentSignature = CStr(count)
    If count = 0 Then Exit Function
    attached = annotation.GetAttachedEntities3
    Require IsArray(attached), "�� ��������� �������� ��������� �������."
    Require UBound(attached) - LBound(attached) + 1 = count, "�������� ������ �������� �������."
    ReDim parts(LBound(attached) To UBound(attached))
    For i = LBound(attached) To UBound(attached)
        Set obj = attached(i)
        Require Not obj Is Nothing, "������ �������� ��������� �������."
        Set component = Nothing
        If TypeOf obj Is SldWorks.Component2 Then
            Set component = obj
        ElseIf TypeOf obj Is SldWorks.DrawingComponent Then
            Set drawingComponent = obj
            Set component = drawingComponent.Component
        Else
            ' Unsupported attachment objects must stop repair, never select another part.
            Set entity = obj
            ' A section entity needs the component instance in this drawing view.
            Set drawingComponent = entity.GetDrawingComponent(view)
            If Not drawingComponent Is Nothing Then Set component = drawingComponent.Component
            If component Is Nothing Then Set component = entity.GetComponent
        End If
        Require Not component Is Nothing, "�� ���������� ������ �������� ��������� �������."
        item = NormalizePath(component.GetPathName) & "|" & component.ReferencedConfiguration & "|" & component.Name2
        parts(i) = item
    Next i
    ' Attachment ordering is not identity. Preserve multiplicity, compare sorted values.
    For i = LBound(parts) To UBound(parts)
        For j = i + 1 To UBound(parts)
            If StrComp(parts(i), parts(j), vbBinaryCompare) > 0 Then
                tmp = parts(i): parts(i) = parts(j): parts(j) = tmp
            End If
        Next j
    Next i
    NoteAttachmentSignature = NoteAttachmentSignature & ":" & Join(parts, vbTab)
End Function

Private Function RemapComponentViews(ByVal raw As String, ByVal mapping As Object) As String
    Dim cursor As Long, marker As Long, closing As Long, start As Long, slash As Long
    Dim expression As String, at As Long, name As String, output As String
    cursor = 1
    Do
        marker = InStr(cursor, raw, "$COMP:" & Chr$(34), vbTextCompare)
        If marker = 0 Then Exit Do
        start = marker + Len("$COMP:" & Chr$(34))
        closing = InStr(start, raw, Chr$(34))
        Require closing > 0, "�� ������� ������ $COMP � �������."
        output = output & Mid$(raw, cursor, start - cursor)
        expression = Mid$(raw, start, closing - start)
        ' Only @view/ qualifiers inside this component expression may change.
        ' Work from the original expression so mappings never cascade (1->2->3).
        Do
            at = InStr(1, expression, "@", vbBinaryCompare)
            If at = 0 Then Exit Do
            slash = InStr(at + 1, expression, "/", vbBinaryCompare)
            If slash = 0 Then Exit Do
            name = Mid$(expression, at + 1, slash - at - 1)
            output = output & Left$(expression, at)
            If mapping.Exists(name) Then
                output = output & CStr(mapping(name)) & "/"
            Else
                output = output & name & "/"
            End If
            expression = Mid$(expression, slash + 1)
        Loop
        output = output & expression & Chr$(34)
        cursor = closing + 1
    Loop
    RemapComponentViews = output & Mid$(raw, cursor)
End Function

Private Function MappedLinkedNotes(ByVal original As Collection, ByVal mapping As Object) As Collection
    Dim result As Collection, item As Variant, rec As Object
    Set result = New Collection
    For Each item In original
        Set rec = CloneRecord(item)
        If rec.Exists("ResolvedLink") Then
            rec("Link") = CStr(rec("ResolvedLink"))
        Else
            rec("Link") = RemapComponentViews(CStr(rec("Link")), mapping)
        End If
        result.Add rec
    Next item
    Set MappedLinkedNotes = result
End Function

Private Function SameNotePosition(ByVal a As Object, ByVal b As Object, _
    Optional ByVal tolerance As Double = POSITION_TOL) As Boolean
    SameNotePosition = NearValue(CDbl(a("X")), CDbl(b("X")), tolerance) And _
        NearValue(CDbl(a("Y")), CDbl(b("Y")), tolerance)
End Function

Private Sub RestoreImportedLinkedNotes(ByVal original As Object, ByVal sheetMap As Object, ByVal viewMap As Object)
    Dim key As Variant, sheetKey As Variant, view As SldWorks.View
    Dim drawing As SldWorks.DrawingDoc, grouped As Object, bucket As Collection
    Set drawing = targetModel
    Set grouped = NewDictionary()
    For Each sheetKey In original("Order")
        Set bucket = New Collection
        grouped.Add CStr(sheetKey), bucket
    Next sheetKey
    For Each key In original("Views").Keys
        If original("Views")(CStr(key))("LinkedNotes").Count > 0 Then
            Set bucket = grouped(CStr(original("Views")(CStr(key))("Sheet")))
            bucket.Add CStr(key)
        End If
    Next key
    ' Empty sheets and views require neither activation nor lookup.
    For Each sheetKey In original("Order")
        Set bucket = grouped(CStr(sheetKey))
        If bucket.Count = 0 And original("Sheets")(CStr(sheetKey))("LinkedNotes").Count = 0 Then GoTo NextNoteSheet
        EnsureSheetActive targetModel, CStr(sheetMap(CStr(sheetKey))), "Restore linked sheet notes"
        If original("Sheets")(CStr(sheetKey))("LinkedNotes").Count > 0 Then
            Set view = drawing.GetFirstView
            RestoreViewLinkedNotes view, original("Sheets")(CStr(sheetKey))("LinkedNotes"), viewMap
        End If
        For Each key In bucket
            Set view = FindView(targetModel, CStr(viewMap(CStr(key))))
            Require Not view Is Nothing, "�� ������ ��� ��� ��������� �������."
            Require SameText(ViewSheetName(view), CStr(sheetMap(CStr(sheetKey)))), "��� ������� ��������� �� ������ �����."
            RestoreViewLinkedNotes view, original("Views")(CStr(key))("LinkedNotes"), viewMap
        Next key
NextNoteSheet:
    Next sheetKey
End Sub

Private Function ComponentNoteShape(ByVal raw As String) As String
    Dim cursor As Long, marker As Long, start As Long, closing As Long, result As String
    cursor = 1
    Do
        marker = InStr(cursor, raw, "$COMP:" & Chr$(34), vbTextCompare)
        If marker = 0 Then Exit Do
        start = marker + Len("$COMP:" & Chr$(34))
        closing = InStr(start, raw, Chr$(34))
        Require closing > 0, "�� ������� ������ $COMP ��� ������������� �������."
        ' Keep property names, formatting and all non-component text unchanged.
        result = result & Mid$(raw, cursor, start - cursor) & "<component>" & Chr$(34)
        cursor = closing + 1
    Loop
    ComponentNoteShape = result & Mid$(raw, cursor)
End Function

Private Function ImportedNoteMatches(ByVal note As SldWorks.Note, ByVal item As Object, _
    ByVal desired As String, ByVal mode As Long, ByVal view As SldWorks.View) As Boolean
    Dim raw As String, annotation As SldWorks.Annotation, p As Variant, marker As Long
    Require Not note Is Nothing, "������ ������ ������� ��� �������������."
    raw = note.PropertyLinkedText
    If mode < 2 Then
        If raw <> CStr(item("Link")) And raw <> desired Then Exit Function
    Else
        If Not IsComponentPropertyNote(raw) Then Exit Function
        ' The fallback can identify one component, not assign several link targets.
        marker = InStr(1, raw, "$COMP:" & Chr$(34), vbTextCompare)
        If InStr(marker + Len("$COMP:"), raw, "$COMP:" & Chr$(34), vbTextCompare) > 0 Then Exit Function
        If Left$(CStr(item("Attachments")), 2) <> "1:" Then Exit Function
        If ComponentNoteShape(raw) <> ComponentNoteShape(CStr(item("Link"))) Then Exit Function
    End If
    Set annotation = note.GetAnnotation
    Require Not annotation Is Nothing, "��� ��������� ��� ������ ��������� �������."
    p = annotation.GetPosition
    Require HasVectorElements(p, 3), "��� ��������� ��� ������ ��������� �������."
    If mode = 0 Or mode = 2 Then
        If Not NearValue(CDbl(p(0)), CDbl(item("X")), GEOM_TOL) Then Exit Function
        If Not NearValue(CDbl(p(1)), CDbl(item("Y")), GEOM_TOL) Then Exit Function
    End If
    If mode > 0 Then
        If NoteAttachmentSignature(annotation, view) <> CStr(item("Attachments")) Then Exit Function
        ' A moved note must retain its complete attachment signature.
        If CStr(item("Attachments")) = "0" Then Exit Function
    End If
    ImportedNoteMatches = True
End Function

Private Sub RestoreViewLinkedNotes(ByVal view As SldWorks.View, ByVal expected As Collection, ByVal mapping As Object)
    Dim notes As Variant, item As Variant, note As SldWorks.Note, candidate As SldWorks.Note
    Dim annotation As SldWorks.Annotation
    Dim desired As String, i As Long, matches As Long, p As Variant
    Dim mode As Long, found As Long, used As Object, moved As Boolean
    Dim beforeAttachments As String, afterAttachments As String, originalLink As String
    If expected.Count = 0 Then Exit Sub
    RequireOwnedPath targetModel.GetPathName
    notes = view.GetNotes
    Require IsArray(notes), "�������� ��������� ������� ���� " & view.GetName2
    Set used = NewDictionary()
    For Each item In expected
        desired = RemapComponentViews(CStr(item("Link")), mapping)
        ' First exact expression+position, then exact expression+all attachments
        ' (including multi-leader notes) with position restored below. Only then
        ' try a changed internal component address for one attached component.
        For mode = 0 To 3
            matches = 0
            Set candidate = Nothing
            For i = LBound(notes) To UBound(notes)
                If Not used.Exists(CStr(i)) Then
                    Set note = notes(i)
                    If ImportedNoteMatches(note, item, desired, mode, view) Then
                        matches = matches + 1
                        found = i
                        Set candidate = note
                    End If
                End If
            Next i
            If matches <> 0 Then Exit For
        Next mode
        If matches <> 1 Then
            LogLine "LINKED NOTE match failed: expected=[" & CStr(item("Link")) & _
                "]; x=" & CStr(item("X")) & "; y=" & CStr(item("Y")) & "; matches=" & matches
            LogLine "LINKED NOTE expected attachments=[" & CStr(item("Attachments")) & "]"
            For i = LBound(notes) To UBound(notes)
                Set note = notes(i)
                Require Not note Is Nothing, "������ ������� � �����������."
                Set annotation = note.GetAnnotation
                Require Not annotation Is Nothing, "��� ��������� ������� � �����������."
                p = annotation.GetPosition
                Require HasVectorElements(p, 3), "��� ��������� ������� � �����������."
                LogLine "LINKED NOTE candidate: name=" & note.GetName & "; raw=[" & _
                    note.PropertyLinkedText & "]; x=" & p(0) & "; y=" & p(1) & _
                    "; attachments=[" & NoteAttachmentSignature(annotation, view) & "]"
            Next i
        End If
        Require matches = 1, "�������������/���������� ��������� �������: " & CStr(item("Name")) & "; ���=" & view.GetName2
        used.Add CStr(found), True
        LogLine "LINKED NOTE matched: mode=" & mode & "; note=" & candidate.GetName
        Set annotation = candidate.GetAnnotation
        originalLink = candidate.PropertyLinkedText
        beforeAttachments = NoteAttachmentSignature(annotation, view)
        LogLine "LINKED NOTE binding before: view=" & view.GetName2 & "; note=" & CStr(item("Name")) & _
            "; expected=[" & CStr(item("Attachments")) & "]; actual=[" & beforeAttachments & "]"
        LogLine "LINKED NOTE expression: original=[" & CStr(item("Link")) & _
            "]; current=[" & originalLink & "]; requested=[" & desired & "]"
        ' Resolve the live reference in the destination view before checking attachments.
        ' No leaders or attachment entities are reassigned here.
        If candidate.PropertyLinkedText <> desired Then candidate.PropertyLinkedText = desired
        Require candidate.PropertyLinkedText = desired, "�� ������������� ������ �������: " & CStr(item("Name"))
        Set annotation = candidate.GetAnnotation
        afterAttachments = NoteAttachmentSignature(annotation, view)
        If afterAttachments = CStr(item("Attachments")) Then
            If InStr(1, originalLink, "SectionAssembly", vbTextCompare) > 0 And _
                Len(Trim$(CStr(item("Text")))) > 0 And Len(Trim$(candidate.GetText)) = 0 Then
                desired = SectionComponentLink(view, annotation, desired, afterAttachments)
                If candidate.PropertyLinkedText <> desired Then candidate.PropertyLinkedText = desired
                Require candidate.PropertyLinkedText = desired, "�� �������� ������ ���������� �������."
                item("ResolvedLink") = desired
                Set annotation = candidate.GetAnnotation
                afterAttachments = NoteAttachmentSignature(annotation, view)
                LogLine "SECTION NOTE rebuilt: view=" & view.GetName2 & "; expression=[" & desired & _
                    "]; text=[" & candidate.GetText & "]"
            End If
        End If
        Set annotation = candidate.GetAnnotation
        p = annotation.GetPosition
        Require HasVectorElements(p, 3), "��� ��������� ��������������� �������."
        If Not NearValue(CDbl(p(0)), CDbl(item("X")), POSITION_TOL) Or _
            Not NearValue(CDbl(p(1)), CDbl(item("Y")), POSITION_TOL) Then
            moved = annotation.SetPosition2(CDbl(item("X")), CDbl(item("Y")), CDbl(p(2)))
            LogLine "LINKED NOTE position restored: api=" & CStr(moved) & "; note=" & candidate.GetName
            p = annotation.GetPosition
            Require HasVectorElements(p, 3), "�� ��������� ������� ������� ����� ��������."
            Require NearValue(CDbl(p(0)), CDbl(item("X")), POSITION_TOL) And _
                NearValue(CDbl(p(1)), CDbl(item("Y")), POSITION_TOL), "�� ������������� ������� ��������� �������."
            afterAttachments = NoteAttachmentSignature(annotation, view)
        End If
        LogLine "LINKED NOTE binding after: view=" & view.GetName2 & "; note=" & CStr(item("Name")) & _
            "; actual=[" & afterAttachments & "]"
        If afterAttachments <> CStr(item("Attachments")) Then
            candidate.PropertyLinkedText = originalLink
            Require False, "���������� ������ �������� �������: " & CStr(item("Name")) & _
                "; ���=" & view.GetName2 & "; ����������� LINKED NOTE binding � merge.log."
        End If
        ' Reset the original layer as paste can inherit the destination's current layer.
        If annotation.Layer <> CStr(item("Layer")) Then annotation.Layer = CStr(item("Layer"))
        If CLng(annotation.Visible) <> CLng(item("Visible")) Then annotation.Visible = CLng(item("Visible"))
        LogLine "LINKED NOTE restored: view=" & view.GetName2 & "; note=" & candidate.GetName & _
            "; sourceText=[" & CStr(item("Text")) & "]; currentText=[" & candidate.GetText & "]"
    Next item
End Sub

Private Sub VerifyLinkedNotes(ByVal expected As Collection, ByVal actual As Collection, ByVal context As String)
    Dim item As Variant, candidate As Variant, count As Long, used As Object, index As Long, found As Long
    Dim pass As Long, tolerance As Double
    Require expected.Count = actual.Count, context & ": ���������� ����� ������� �� ���������� �������."
    Set used = NewDictionary()
    For Each item In expected
        ' Keep exact matching first to distinguish nearby identical notes.
        For pass = 0 To 1
            tolerance = GEOM_TOL
            If pass = 1 Then tolerance = POSITION_TOL
            count = 0
            index = 0
            For Each candidate In actual
                index = index + 1
                If Not used.Exists(CStr(index)) Then
                    If CStr(item("Link")) = CStr(candidate("Link")) And SameNotePosition(item, candidate, tolerance) Then
                        If CStr(item("Attachments")) = CStr(candidate("Attachments")) Then
                            count = count + 1
                            found = index
                        End If
                    End If
                End If
            Next candidate
            If count <> 0 Then Exit For
        Next pass
        Require count = 1, context & ": ��������/������������ ������ ������� " & CStr(item("Name"))
        used.Add CStr(found), True
        Set candidate = actual(found)
        If CStr(item("Layer")) <> CStr(candidate("Layer")) Then LogLine "LAYOUT WARNING: ���� ������� " & CStr(item("Name"))
        Require CLng(item("Visible")) = CLng(candidate("Visible")), context & ": ���������� ��������� ������� " & CStr(item("Name"))
        If Len(Trim$(CStr(item("Text")))) > 0 Then
            LogLine "LINKED NOTE check [" & context & "]: note=" & CStr(item("Name")) & _
                "; expected=[" & CStr(item("Text")) & "]; actual=[" & CStr(candidate("Text")) & "]"
            Require CStr(item("Text")) = CStr(candidate("Text")), context & _
                ": ������/��������� ����� ��������� ������� " & CStr(item("Name"))
        End If
    Next item
End Sub


' Use the native drawing instance chain, including the generated SectionAssembly.
Private Function SectionComponentLink(ByVal view As SldWorks.View, ByVal annotation As SldWorks.Annotation, _
    ByVal raw As String, ByVal signature As String) As String
    Dim attached As Variant, obj As Object, entity As SldWorks.Entity
    Dim node As SldWorks.DrawingComponent, component As SldWorks.Component2
    Dim names As Variant, expression As String, unique As String, i As Long
    Dim marker As Long, start As Long, closing As Long, identity As String
    Require Left$(signature, 2) = "1:", "��������� ������ ������� ����� ��������� ��������."
    marker = InStr(1, raw, "$COMP:" & Chr$(34), vbTextCompare)
    Require marker > 0, "��� ������ ���������� �������."
    start = marker + Len("$COMP:" & Chr$(34))
    closing = InStr(start, raw, Chr$(34))
    Require closing > 0, "�� ������� ������ ���������� �������."
    Require InStr(closing + 1, raw, "$COMP:", vbTextCompare) = 0, "��������� ������ ����������� � ������� �������."
    attached = annotation.GetAttachedEntities3
    Require IsArray(attached), "�� ��������� �������� ������� �������."
    Require UBound(attached) = LBound(attached), "��������� ���� �������� ������� �������."
    Set obj = attached(LBound(attached))
    If TypeOf obj Is SldWorks.DrawingComponent Then
        Set node = obj
    ElseIf TypeOf obj Is SldWorks.Component2 Then
        Set component = obj
        Set node = component.GetDrawingComponent(view)
    Else
        Set entity = obj
        Set node = entity.GetDrawingComponent(view)
    End If
    Require Not node Is Nothing, "��� ��������� DrawingComponent �������� �������."
    Set component = node.Component
    Require Not component Is Nothing, "��� ���������� �������� �������."
    identity = NormalizePath(component.GetPathName) & "|" & component.ReferencedConfiguration & "|" & component.Name2
    Require identity = Mid$(signature, 3), "�������� ������� ������� ��������� �������."
    unique = view.GetUniqueName
    Require Len(unique) > 0, "��� ����������� ����� ���� �������."
    names = Split(node.Name, "/")
    Require UBound(names) >= 1, "�� ��������� ������ ������� ����������� �������."
    Require InStr(1, CStr(names(0)), "SectionAssembly", vbTextCompare) > 0, "��� ��������� ������ � ������� �������."
    expression = CStr(names(0)) & "@" & unique
    For i = 1 To UBound(names)
        expression = expression & "/" & CStr(names(i)) & "@" & InstanceModelName(CStr(names(i - 1)))
    Next i
    Require InStr(expression, Chr$(34)) = 0, "���������������� ������� � ������ ����������."
    LogLine "SECTION NOTE native address: unique=" & unique & "; chain=[" & node.Name & "]; componentID=[" & component.GetSelectByIDString & "]"
    SectionComponentLink = Left$(raw, start - 1) & expression & Mid$(raw, closing)
End Function

Private Function InstanceModelName(ByVal instance As String) As String
    Dim dash As Long, suffix As String, i As Long
    dash = InStrRev(instance, "-")
    Require dash > 1 And dash < Len(instance), "��� ������ ����������: " & instance
    suffix = Mid$(instance, dash + 1)
    For i = 1 To Len(suffix)
        Require Mid$(suffix, i, 1) >= "0" And Mid$(suffix, i, 1) <= "9", "���������������� ����� ����������: " & instance
    Next i
    InstanceModelName = Left$(instance, dash - 1)
End Function

Private Function GetOrderedSourceFiles(ByVal selectedFiles As Collection, _
    ByVal mainPath As String) As Collection
    Dim dialog As frmDrawingOrder, item As Variant, result As Collection
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    Set dialog = New frmDrawingOrder
    dialog.LoadCandidates selectedFiles, mainPath
    dialog.Show vbModal
    If dialog.Accepted Then
        Set result = dialog.SelectedFiles
        Set GetOrderedSourceFiles = result
        LogLine "������� �������� �������� (����� VBA):"
        For Each item In result
            LogLine CStr(item)
        Next item
    End If
    Unload dialog
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If Not dialog Is Nothing Then Unload dialog
    On Error GoTo 0
    Err.Raise errorNumber, "GetOrderedSourceFiles", errorText
End Function

Public Function OrderPickFiles(ByVal mainPath As String) As Collection
    Set OrderPickFiles = PickMultipleDrawings("�������� �������� �������", GetFolder(mainPath))
End Function

Public Function OrderFolderFiles(ByVal folder As String, ByVal mainPath As String) As Collection
    Set OrderFolderFiles = GetAllDrawingsInFolder(folder, mainPath)
End Function

Private Function PickOneDrawing( _
    ByVal dialogTitle As String, _
    ByVal initialFolder As String) As String

    Dim ofn As OPENFILENAMEW
    Dim filter As String
    Dim buffer As String
    Dim titleBuffer As String
    Dim p As Long

    filter = "������� SOLIDWORKS (*.slddrw)" & vbNullChar & _
             "*.slddrw" & vbNullChar & _
             "��� ����� (*.*)" & vbNullChar & _
             "*.*" & vbNullChar & vbNullChar

    buffer = String$(32767, vbNullChar)
    titleBuffer = String$(1024, vbNullChar)

    With ofn
        .lStructSize = LenB(ofn)
        .lpstrFilter = StrPtr(filter)
        .nFilterIndex = 1
        .lpstrFile = StrPtr(buffer)
        .nMaxFile = Len(buffer)
        .lpstrFileTitle = StrPtr(titleBuffer)
        .nMaxFileTitle = Len(titleBuffer)
        .lpstrTitle = StrPtr(dialogTitle)
        .Flags = OFN_EXPLORER Or OFN_FILEMUSTEXIST Or _
                 OFN_PATHMUSTEXIST Or OFN_HIDEREADONLY

        If initialFolder <> "" Then .lpstrInitialDir = StrPtr(initialFolder)
    End With

    If GetOpenFileNameW(ofn) = 0 Then
        PickOneDrawing = ""
        Exit Function
    End If

    p = InStr(1, buffer, vbNullChar)

    If p > 0 Then
        PickOneDrawing = Left$(buffer, p - 1)
    Else
        PickOneDrawing = buffer
    End If

End Function

Private Function GetAllDrawingsInFolder( _
    ByVal folderPath As String, _
    ByVal mainPath As String) As Collection

    Dim fso As Object
    Dim folder As Object
    Dim file As Object
    Dim files As New Collection
    Dim seen As Object
    Dim fullPath As String

    Set fso = CreateObject("Scripting.FileSystemObject")
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    If Len(folderPath) = 0 Or Not fso.FolderExists(folderPath) Then
        Set GetAllDrawingsInFolder = files
        Exit Function
    End If

    Set folder = fso.GetFolder(folderPath)
    For Each file In folder.files
        If LCase$(fso.GetExtensionName(file.name)) = "slddrw" Then
            If Left$(file.name, 2) = "~$" Then
                Debug.Print "��������� ���� ��������: " & file.Path
            ElseIf LCase$(file.name) Like "merged_########_######*.slddrw" Then
                Debug.Print "������� ��������� ��������: " & file.Path
            Else
            fullPath = file.Path
            If StrComp(Replace(fullPath, "/", "\"), Replace(mainPath, "/", "\"), vbTextCompare) <> 0 Then
                If Not seen.Exists(fullPath) Then
                    seen.Add fullPath, True
                    files.Add fullPath
                End If
            Else
                Debug.Print "�������� ����� ������������� ��������: " & fullPath
            End If
            End If
        End If
    Next file

    Set GetAllDrawingsInFolder = files
End Function

' =========================================================
' ������ ������ ���������� ��������
' =========================================================

Private Function PickMultipleDrawings( _
    ByVal dialogTitle As String, _
    ByVal initialFolder As String) As Collection

    Dim ofn As OPENFILENAMEW
    Dim filter As String
    Dim buffer As String
    Dim titleBuffer As String
    Dim raw As String
    Dim parts As Variant
    Dim files As New Collection
    Dim folder As String
    Dim i As Long
    Dim p As Long

    filter = "������� SOLIDWORKS (*.slddrw)" & vbNullChar & _
             "*.slddrw" & vbNullChar & _
             "��� ����� (*.*)" & vbNullChar & _
             "*.*" & vbNullChar & vbNullChar

    buffer = String$(32767, vbNullChar)
    titleBuffer = String$(1024, vbNullChar)

    With ofn
        .lStructSize = LenB(ofn)
        .lpstrFilter = StrPtr(filter)
        .nFilterIndex = 1
        .lpstrFile = StrPtr(buffer)
        .nMaxFile = Len(buffer)
        .lpstrFileTitle = StrPtr(titleBuffer)
        .nMaxFileTitle = Len(titleBuffer)
        .lpstrTitle = StrPtr(dialogTitle)
        .Flags = OFN_EXPLORER Or OFN_ALLOWMULTISELECT Or _
                 OFN_FILEMUSTEXIST Or OFN_PATHMUSTEXIST Or _
                 OFN_HIDEREADONLY

        If initialFolder <> "" Then .lpstrInitialDir = StrPtr(initialFolder)
    End With

    If GetOpenFileNameW(ofn) = 0 Then
        Set PickMultipleDrawings = Nothing
        Exit Function
    End If

    p = InStr(1, buffer, vbNullChar & vbNullChar)

    If p > 0 Then
        raw = Left$(buffer, p - 1)
    Else
        raw = buffer
    End If

    parts = Split(raw, vbNullChar)

    If UBound(parts) = 0 Then

        If Len(CStr(parts(0))) > 0 Then
            files.Add CStr(parts(0))
        End If

    Else

        folder = CStr(parts(0))

        For i = 1 To UBound(parts)
            If Len(CStr(parts(i))) > 0 Then
                files.Add folder & "\" & CStr(parts(i))
            End If
        Next i

    End If

    Set PickMultipleDrawings = files

End Function

' =========================================================
' ���� ��������� �������
' =========================================================

Private Function GetFolder(ByVal filePath As String) As String

    Dim p As Long

    p = InStrRev(filePath, "\")

    If p > 0 Then
        GetFolder = Left$(filePath, p - 1)
    Else
        GetFolder = ""
    End If

End Function


' =========================================================
' ������� ������� � PDF
' =========================================================

Private Function ElapsedSeconds(ByVal started As Double) As Double
    Dim seconds As Double
    seconds = Timer - started
    If seconds < 0 Then seconds = seconds + 86400#
    ElapsedSeconds = seconds
End Function

Private Sub InitFailureLog()
    Dim folder As String
    ' Called only by the failure handler under On Error Resume Next.
    If fsoRun Is Nothing Then Set fsoRun = CreateObject("Scripting.FileSystemObject")
    folder = fsoRun.BuildPath(fsoRun.GetSpecialFolder(2).Path, "DrawingMerger_V16_27")
    If Not fsoRun.FolderExists(folder) Then fsoRun.CreateFolder folder
    InitRunFolder fsoRun.BuildPath(folder, "failure.slddrw")
    LogLine "BUILD_ID: " & BUILD_ID
    LogLine "Fallback log: " & runFolder
End Sub

Private Sub PublishPDF(ByVal stagedPath As String, ByVal finalPath As String)
    Dim previousPath As String, hadPrevious As Boolean, publishing As Boolean
    Dim number As Long, message As String
    On Error GoTo Failed
    RequireOwnedPath stagedPath
    Require fsoRun.FileExists(stagedPath), "������� PDF �����������."
    Require fsoRun.GetFile(stagedPath).Size > 0, "������� PDF ����."
    previousPath = fsoRun.BuildPath(runFolder, "PREVIOUS_PDF.pdf")
    hadPrevious = fsoRun.FileExists(finalPath)
    If hadPrevious Then fsoRun.CopyFile finalPath, previousPath, False
    publishing = True
    fsoRun.CopyFile stagedPath, finalPath, True
    Require fsoRun.FileExists(finalPath), "�������� PDF �����������."
    Require fsoRun.GetFile(finalPath).Size = fsoRun.GetFile(stagedPath).Size, "������ ��������� PDF �� ���������."
    LogLine "PDF published: " & finalPath & "; bytes=" & fsoRun.GetFile(finalPath).Size
    Exit Sub
Failed:
    number = Err.Number
    message = Err.Description
    On Error Resume Next
    If publishing Then
        Err.Clear
        If hadPrevious Then
            fsoRun.CopyFile previousPath, finalPath, True
        ElseIf fsoRun.FileExists(finalPath) Then
            fsoRun.DeleteFile finalPath, False
        End If
        If Err.Number <> 0 Then LogLine "PDF rollback failed: " & Err.Number & ": " & Err.Description
    End If
    On Error GoTo 0
    Err.Raise number, "PublishPDF", message
End Sub

Private Function ExportDrawingToPDF(ByVal model As SldWorks.ModelDoc2, _
    ByVal pdfPath As String, ByRef exportErrors As Long, ByRef exportWarnings As Long) As Boolean
    Dim pdfData As SldWorks.ExportPdfData, drawing As SldWorks.DrawingDoc
    Dim names As Variant, configured As Boolean, saved As Boolean, started As Double
    On Error GoTo Failed
    exportErrors = 0
    exportWarnings = 0
    Require Not model Is Nothing, "�� ����� ������ ��� PDF."
    Require model.GetType = swDocDRAWING, "��� PDF ����� ������."
    Require Len(model.GetPathName) > 0, "������ �� ��������."
    RequireOwnedPath pdfPath
    RequireActive model
    model.ClearSelection2 True
    Set drawing = model
    names = drawing.GetSheetNames
    Require HasVectorElements(names, 1), "�� �������� ����� ��� PDF."
    Set pdfData = swApp.GetExportFileData(swExportPdfData)
    Require Not pdfData Is Nothing, "�� ������� ��������� PDF."
    pdfData.ExportAs3D = False
    pdfData.ViewPdfAfterSaving = False
    ' Explicitly include every current sheet, independent of the UI's last export.
    configured = pdfData.SetSheets(swExportData_ExportSpecifiedSheets, names)
    Require configured, "�� ����� ������ ������ ������ ��� PDF."
    started = Timer
    saved = model.Extension.SaveAs(pdfPath, 0, swSaveAsOptions_Silent, pdfData, exportErrors, exportWarnings)
    LogLine "PDF export: " & pdfPath & "; sheets=" & CStr(UBound(names) - LBound(names) + 1) & _
        "; saved=" & CStr(saved) & "; errors=" & exportErrors & "; warnings=" & exportWarnings & _
        "; seconds=" & Format$(ElapsedSeconds(started), "0.000")
    ExportDrawingToPDF = saved And exportErrors = 0
    Exit Function
Failed:
    exportErrors = Err.Number
    LogLine "PDF export failed: " & exportErrors & ": " & Err.Description
End Function

Private Function CaptureMappedSheets(ByVal model As SldWorks.ModelDoc2, ByVal mapping As Object) As Object
    Dim selected As Object, key As Variant
    Set selected = NewDictionary()
    For Each key In mapping.Keys
        selected(CStr(mapping(key))) = True
    Next key
    Require selected.Count > 0, "�� ������ ����������� ����� ��� ������."
    Set CaptureMappedSheets = CaptureDrawing(model, "", selected)
End Function

Private Function CaptureStructure(ByVal model As SldWorks.ModelDoc2, ByVal touched As Object) As Object
    Dim drawing As SldWorks.DrawingDoc, sheet As SldWorks.Sheet
    Dim view As SldWorks.View, parent As SldWorks.View, refDoc As SldWorks.ModelDoc2
    Dim result As Object, views As Object, rec As Object, key As Variant
    Dim originalSheet As String, guard As Long
    RequireActive model
    Set drawing = model
    Set sheet = drawing.GetCurrentSheet
    Require Not sheet Is Nothing, "��� �������� ����� ������������ ������."
    originalSheet = sheet.GetName
    Set result = NewDictionary()
    Set views = NewDictionary()
    For Each key In touched.Keys
        EnsureSheetActive model, CStr(key), "CaptureStructure"
        Set view = drawing.GetFirstView
        Require Not view Is Nothing, "��� ���������� ���� ������������ ������."
        Require view.Type = swDrawingSheet, "������ ��� �� �������� ���������."
        Set view = view.GetNextView
        Do While Not view Is Nothing
            guard = guard + 1
            Require guard <= MAX_ITEMS, "������������ ������������ ������."
            Set rec = NewDictionary()
            rec.Add "Type", CLng(view.Type)
            rec.Add "Model", NormalizePath(view.GetReferencedModelName)
            rec.Add "Configuration", view.ReferencedConfiguration
            If Len(CStr(rec("Model"))) > 0 Then
                Set refDoc = view.ReferencedDocument
                Require Not refDoc Is Nothing, "�� ��������� ������ ������������ ������."
                SuspendDocumentUI refDoc
                rec("Model") = NormalizePath(refDoc.GetPathName)
            End If
            rec.Add "Parent", ""
            Set parent = view.GetBaseView
            If Not parent Is Nothing Then rec("Parent") = parent.GetName2
            If view.Type = swDrawingSectionView Or view.Type = swDrawingDetailView Then
                Require Not parent Is Nothing, "� ���������� ���� ��� ��������."
            End If
            rec.Add "Dimensions", CLng(view.GetDimensionCount4)
            rec.Add "ApprovedOmissions", ApprovedDimensionCount(view)
            Require Not views.Exists(view.GetName2), "������������� ��� ������������ ������."
            views.Add view.GetName2, rec
            Set view = view.GetNextView
        Loop
    Next key
    result.Add "Views", views
    EnsureSheetActive model, originalSheet, "CaptureStructure restore"
    Set CaptureStructure = result
End Function

Private Function PerfClock() As Double
    ' Monotonic uptime in seconds; independent of midnight and clock changes.
    PerfClock = CDbl(GetTickCount64()) / 1000#
End Function

Private Sub PerfStart()
    Set perfRows = New Collection
    perfStarted = PerfClock()
    perfStage = ""
    perfActive = True
    LogLine "TIMING START: computation only; file selection dialogs excluded"
End Sub

Private Sub PerfCloseStage(ByVal tick As Double, ByVal status As String)
    Dim seconds As Double, cumulative As Double, row As String
    If Len(perfStage) = 0 Then Exit Sub
    seconds = tick - perfStageStarted
    cumulative = tick - perfStarted
    row = perfStage & vbTab & PerfNumber(seconds) & vbTab & PerfNumber(cumulative) & vbTab & status
    perfRows.Add row
    LogLine "TIMING " & perfStage & ": seconds=" & PerfNumber(seconds) & "; status=" & status
    perfStage = ""
End Sub

Private Function PerfNumber(ByVal seconds As Double) As String
    PerfNumber = Replace(Format$(seconds, "0.000"), ",", ".")
End Function

Private Sub PerfNext(ByVal stage As String)
    Dim tick As Double
    If Not perfActive Then Exit Sub
    tick = PerfClock()
    PerfCloseStage tick, "DONE"
    perfStage = stage
    perfStageStarted = tick
End Sub

Private Sub PerfFinish(ByVal status As String)
    Dim tick As Double, seconds As Double, stream As Object, row As Variant
    Dim number As Long, message As String
    On Error GoTo Failed
    If Not perfActive Then Exit Sub
    tick = PerfClock()
    perfActive = False
    If status = "SUCCESS" Then
        PerfCloseStage tick, "DONE"
    Else
        PerfCloseStage tick, status
    End If
    seconds = tick - perfStarted
    LogLine "TIMING TOTAL: seconds=" & PerfNumber(seconds) & "; status=" & status
    perfRows.Add "TOTAL" & vbTab & PerfNumber(seconds) & vbTab & PerfNumber(seconds) & vbTab & status
    Set stream = fsoRun.CreateTextFile(runFolder & "\TIMING.tsv", True, True)
    stream.WriteLine "BUILD_ID" & vbTab & BUILD_ID
    stream.WriteLine "RUN" & vbTab & runToken
    stream.WriteLine "MODE" & vbTab & "computation_only; source dialogs excluded; stages are exclusive; TOTAL includes stages"
    stream.WriteLine "stage" & vbTab & "seconds" & vbTab & "cumulative_seconds" & vbTab & "status"
    For Each row In perfRows
        stream.WriteLine CStr(row)
    Next row
    stream.Close
    Set perfRows = Nothing
    Exit Sub
Failed:
    number = Err.Number
    message = Err.Description
    On Error Resume Next
    perfActive = False
    If Not stream Is Nothing Then stream.Close
    Set perfRows = Nothing
    LogLine "TIMING REPORT FAILED " & number & ": " & message
End Sub

Private Sub DetailStart(ByVal fileIndex As Long)
    detailPrefix = "DETAIL_SOURCE_" & Format$(fileIndex, "0000") & "/"
    detailStage = ""
    detailActive = True
End Sub

Private Sub DetailNext(ByVal stage As String)
    Dim tick As Double
    If Not detailActive Then Exit Sub
    tick = PerfClock()
    DetailClose tick, "DONE"
    detailStage = stage
    detailStarted = tick
End Sub

Private Sub DetailClose(ByVal tick As Double, ByVal status As String)
    Dim label As String, seconds As Double
    If Len(detailStage) = 0 Then Exit Sub
    label = detailPrefix & detailStage
    seconds = tick - detailStarted
    perfRows.Add label & vbTab & PerfNumber(seconds) & vbTab & PerfNumber(tick - perfStarted) & vbTab & status
    LogLine "TIMING " & label & ": seconds=" & PerfNumber(seconds) & "; status=" & status
    detailStage = ""
End Sub

Private Sub DetailFinish(ByVal status As String)
    If Not detailActive Then Exit Sub
    detailActive = False
    DetailClose PerfClock(), status
End Sub

Private Sub StartUIExperiment()
    RestoreAllUI
    Set uiStates = NewDictionary()
    uiEnabled = True
    LogLine "UI START: feature=" & CStr(SUPPRESS_FEATURE_TREE) & "; configuration=" & _
        CStr(SUPPRESS_CONFIGURATION_TREE) & "; graphics=" & CStr(SUPPRESS_GRAPHICS)
End Sub

Private Function TryGetUIManager(ByVal model As SldWorks.ModelDoc2, ByVal propertyName As String) As Object
    Dim number As Long
    On Error Resume Next
    Err.Clear
    Set TryGetUIManager = CallByName(model, propertyName, VbGet)
    number = Err.Number
    Err.Clear
    On Error GoTo 0
    If number <> 0 Then LogLine "UI manager unavailable: " & propertyName & "; error=" & number
End Function

Private Sub SuspendDocumentUI(ByVal model As SldWorks.ModelDoc2)
    Dim key As String, state As Object, manager As Object
    If Not uiEnabled Then Exit Sub
    If model Is Nothing Then Exit Sub
    key = NormalizePath(model.GetPathName)
    If Len(key) = 0 Then Exit Sub
    If uiStates.Exists(key) Then Exit Sub
    Set state = NewDictionary()
    state.Add "Model", model
    state.Add "IsDrawing", CBool(model.GetType = swDocDRAWING)
    Set manager = TryGetUIManager(model, "FeatureManager")
    state.Add "Feature", manager
    Set manager = TryGetUIManager(model, "ConfigurationManager")
    state.Add "Configuration", manager
    Set manager = TryGetUIManager(model, "ActiveView")
    state.Add "Graphics", manager
    state.Add "FeatureHeld", False
    state.Add "WindowHeld", False
    state.Add "ConfigurationHeld", False
    state.Add "GraphicsHeld", False
    uiStates.Add key, state
    If SUPPRESS_FEATURE_TREE Then
        ' Prevent interactive use of a temporarily stale tree while it is frozen.
        SuspendUIFlag state, "Feature", "EnableFeatureTreeWindow", "WindowPrevious", "WindowHeld"
        SuspendUIFlag state, "Feature", "EnableFeatureTree", "FeaturePrevious", "FeatureHeld"
    End If
    If SUPPRESS_CONFIGURATION_TREE Then
        SuspendUIFlag state, "Configuration", "EnableConfigurationTree", "ConfigurationPrevious", "ConfigurationHeld"
    End If
    If SUPPRESS_GRAPHICS Then
        SuspendUIFlag state, "Graphics", "EnableGraphicsUpdate", "GraphicsPrevious", "GraphicsHeld"
    End If
    LogLine "UI guarded: " & key
End Sub

Private Sub SuspendUIFlag(ByVal state As Object, ByVal managerKey As String, ByVal propertyName As String, _
    ByVal previousKey As String, ByVal heldKey As String)
    Dim manager As Object, previous As Boolean, actual As Boolean
    Dim number As Long, message As String, recovered As Boolean
    On Error GoTo Failed
    Set manager = state(managerKey)
    If manager Is Nothing Then
        LogLine "UI skip: " & propertyName & "; manager unavailable"
        Exit Sub
    End If
    previous = FlagValue(CBool(CallByName(manager, propertyName, VbGet)))
    state.Add previousKey, previous
    state(heldKey) = True
    CallByName manager, propertyName, VbLet, False
    actual = FlagValue(CBool(CallByName(manager, propertyName, VbGet)))
    Require actual = False, "�� ��������� ���������� ����������: " & propertyName
    LogLine "UI disabled: " & propertyName & "; previous=" & CStr(previous)
    Exit Sub
Failed:
    number = Err.Number
    message = Err.Description
    If CBool(state(heldKey)) Then
        recovered = TryRestoreUIFlag(state, managerKey, propertyName, previousKey, heldKey)
        If recovered Then
            LogLine "UI suppression unavailable; original state restored: " & propertyName & "; error=" & number
        Else
            Err.Raise number, "SuspendUIFlag", message
        End If
    Else
        LogLine "UI property unavailable; skipped: " & propertyName & "; error=" & number
    End If
End Sub

Private Function TryRestoreUIFlag(ByVal state As Object, ByVal managerKey As String, ByVal propertyName As String, _
    ByVal previousKey As String, ByVal heldKey As String) As Boolean
    Dim manager As Object, actual As Boolean, number As Long, message As String
    On Error GoTo Failed
    TryRestoreUIFlag = True
    If Not CBool(state(heldKey)) Then Exit Function
    Set manager = state(managerKey)
    CallByName manager, propertyName, VbLet, CBool(state(previousKey))
    actual = FlagValue(CBool(CallByName(manager, propertyName, VbGet)))
    Require actual = CBool(state(previousKey)), "�� ������������� ���������� ����������: " & propertyName
    state(heldKey) = False
    Exit Function
Failed:
    number = Err.Number
    message = Err.Description
    TryRestoreUIFlag = False
    On Error Resume Next
    LogLine "UI RESTORE FAILED: " & propertyName & "; error=" & number & ": " & message
End Function

Private Function TryRestoreUIState(ByVal key As String) As Boolean
    Dim state As Object, restored As Boolean, number As Long, message As String
    On Error GoTo Failed
    Set state = uiStates(key)
    restored = True
    If TryRestoreUIFlag(state, "Configuration", "EnableConfigurationTree", "ConfigurationPrevious", "ConfigurationHeld") = False Then restored = False
    If TryRestoreUIFlag(state, "Feature", "EnableFeatureTree", "FeaturePrevious", "FeatureHeld") = False Then restored = False
    If TryRestoreUIFlag(state, "Graphics", "EnableGraphicsUpdate", "GraphicsPrevious", "GraphicsHeld") = False Then restored = False
    If TryRestoreUIFlag(state, "Feature", "EnableFeatureTreeWindow", "WindowPrevious", "WindowHeld") = False Then restored = False
    If restored Then
        uiStates.Remove key
        LogLine "UI restored: " & key
    End If
    TryRestoreUIState = restored
    Exit Function
Failed:
    number = Err.Number
    message = Err.Description
    TryRestoreUIState = False
    On Error Resume Next
    LogLine "UI STATE RESTORE FAILED: " & key & "; error=" & number & ": " & message
End Function

Private Sub RestoreReferenceUI()
    Dim key As Variant, state As Object, restored As Boolean
    If uiStates Is Nothing Then Exit Sub
    restored = True
    For Each key In uiStates.Keys
        Set state = uiStates(CStr(key))
        If CBool(state("IsDrawing")) = False Then
            If TryRestoreUIState(CStr(key)) = False Then restored = False
        End If
    Next key
    Require restored, "�� ������������ ��������� ��������� ������� ����� ��������� �������."
End Sub

Private Sub BeforeCloseUI(ByVal model As SldWorks.ModelDoc2)
    Dim key As String
    If uiStates Is Nothing Then Exit Sub
    key = NormalizePath(model.GetPathName)
    If uiStates.Exists(key) Then
        Require TryRestoreUIState(key), "�� ������������ ��������� ������������ ���������."
    End If
    ' A drawing close can also unload referenced model documents.
    RestoreReferenceUI
End Sub

Private Sub RestoreAllUI()
    Dim key As Variant, restored As Boolean
    uiEnabled = False
    If uiStates Is Nothing Then Exit Sub
    restored = True
    For Each key In uiStates.Keys
        If TryRestoreUIState(CStr(key)) = False Then restored = False
    Next key
    Require restored, "�� ��� ��������� ���������� �������������; ��������� UI RESTORE FAILED � �������."
End Sub
