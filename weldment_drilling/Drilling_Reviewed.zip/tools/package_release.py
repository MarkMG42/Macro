"""Export Windows-1251 import module and deterministic review archive (stdlib only)."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    source = ROOT / 'InsertWeldWithHoles.txt'
    code = source.read_text(encoding='utf-8')
    module = ROOT / 'InsertWeldWithHoles.bas'
    module.write_bytes(code.replace('\n', '\r\n').encode('cp1251'))
    assert module.read_text(encoding='cp1251') == code
    grammar = json.loads((ROOT / 'checks/grammar.json').read_text())
    assert not grammar['errors'], 'VBA grammar errors'
    assert grammar['source_sha256'] == sha(source), 'Rerun grammar validation for this source'
    swp = ROOT / 'Сверловка_исправлено.swp'
    if swp.exists():
        binary = json.loads((ROOT / 'checks/swp.json').read_text())
        assert binary['output_sha256'] == sha(swp), 'SWP checksum mismatch'
        assert binary['source_sha256'] == sha(source), 'Rebuild SWP after modifying source'
        assert binary['import_module_sha256'] == sha(module), 'SWP module differs from exported BAS'
    report = dict(source_sha256=sha(source), import_module_sha256=sha(module),
                  original_module_sha256=sha(ROOT / 'original/InsertWeldWithHoles.bas'),
                  native_vba_compile=False, native_solidworks_run=False,
                  binary_swp_rebuilt=swp.exists(), native_solidworks_load=False, original_swp_sha256=
                  'ed7d9dc23db5bead52dc6208b314897fd7c96cf735f4ce82b0f945101c82363e')
    (ROOT / 'checks/release.json').write_text(json.dumps(report, indent=2) + '\n')
    archive = ROOT / 'Drilling_Reviewed.zip'
    files = sorted(p for p in ROOT.rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts
                   and p not in (archive, ROOT / 'SHA256SUMS.txt'))
    sums = ROOT / 'SHA256SUMS.txt'
    sums.write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT).as_posix()}\n' for p in files), encoding='utf-8')
    files.append(sums)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in files:
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 10, 29, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for path in files:
            assert z.read(path.relative_to(ROOT).as_posix()) == path.read_bytes()
    print(f'Validated {archive.name}: {sha(archive)}')


if __name__ == '__main__':
    main()
